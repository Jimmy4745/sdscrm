import React, { useState, useMemo, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  LayoutDashboard, Package, Users, Wallet, CalendarDays, Truck,
  Plus, Pencil, Trash2, X, Settings as SettingsIcon, Search, CornerDownRight,
  ChevronLeft, ChevronRight, Bell, Download, AlertTriangle, LogOut
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid
} from 'recharts';

// ---------------------------------------------------------------------------
// SUPABASE — plain fetch() against the auto-generated REST + Auth API.
// No @supabase/supabase-js import: that package isn't in this artifact
// sandbox's resolvable library set, so we talk to PostgREST / GoTrue
// directly over HTTP, which only needs the native fetch() API.
// ---------------------------------------------------------------------------

const SUPABASE_URL = 'https://qogfpebivmdkjsdbcjnm.supabase.co';
const SUPABASE_KEY = 'sb_publishable_gNKCUa-XYPF-U4sspSXyGg__8ZLxT5w';

async function sbRequest(path, { method = 'GET', body, accessToken, prefer } = {}) {
  const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': `Bearer ${accessToken || SUPABASE_KEY}`,
    'Content-Type': 'application/json',
  };
  if (prefer) headers['Prefer'] = prefer;
  const res = await fetch(`${SUPABASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try { const err = await res.json(); message = err.msg || err.message || err.error_description || message; } catch (e) {}
    throw new Error(message);
  }
  if (res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

const sbTable = (table, accessToken) => ({
  list: (query = '') => sbRequest(`/rest/v1/${table}?${query}`, { accessToken }),
  insert: (row) => sbRequest(`/rest/v1/${table}`, { method: 'POST', body: row, accessToken, prefer: 'return=representation' }),
  update: (id, row) => sbRequest(`/rest/v1/${table}?id=eq.${id}`, { method: 'PATCH', body: row, accessToken, prefer: 'return=representation' }),
  remove: (id) => sbRequest(`/rest/v1/${table}?id=eq.${id}`, { method: 'DELETE', accessToken }),
});

async function authSignUp(email, password) {
  return sbRequest('/auth/v1/signup', { method: 'POST', body: { email, password } });
}
async function authSignIn(email, password) {
  return sbRequest('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
}
async function authRefresh(refreshToken) {
  return sbRequest('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: refreshToken } });
}

// Field-name mapping helpers between the JS (camelCase) Load shape used
// throughout the UI and the snake_case columns in the `loads` table.
function loadToDb(l) {
  return {
    load_number: l.loadNumber,
    is_partial: l.isPartial,
    parent_load_number: l.isPartial ? (l.parentLoadNumber || null) : null,
    driver_id: l.driverId || null,
    from_city: l.from || null,
    to_city: l.to || null,
    status: l.status,
    pickup_date: l.pickupDate || null,
    delivery_date: l.deliveryDate || null,
    total: l.total,
  };
}
function loadFromDb(r) {
  return {
    id: r.id,
    loadNumber: r.load_number,
    isPartial: r.is_partial,
    parentLoadNumber: r.parent_load_number || '',
    driverId: r.driver_id || '',
    from: r.from_city || '',
    to: r.to_city || '',
    status: r.status,
    pickupDate: r.pickup_date || '',
    deliveryDate: r.delivery_date || '',
    total: Number(r.total),
  };
}

// ---------------------------------------------------------------------------
// DATA SHAPES
// Load:   { id, loadNumber, isPartial, parentLoadNumber, driverId, from, to,
//           status: 'available' | 'pickedup' | 'delivered',
//           pickupDate, deliveryDate: 'YYYY-MM-DD', total }
// Driver: { id, firstName, lastName, truckNumber, type: 'company' | 'owner' }
// Settings: { fullPct, partialPct, dispatcherName } — fullPct/partialPct are
// the fixed dispatch fee % applied to every load company-wide (set on the
// Settings page), dispatcherName is shown in the sidebar.
// All three live as state in DispatchCRM. Dashboard filters loads by
// pickupDate for the selected period, and treats a load as "Order" (full)
// when isPartial is false, or "Partial" when isPartial is true.
// ---------------------------------------------------------------------------

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'loads', label: 'Loads', icon: Package },
  { id: 'drivers', label: 'Drivers', icon: Users },
  { id: 'salary', label: 'Salary', icon: Wallet },
  { id: 'calendar', label: 'Calendar', icon: CalendarDays },
  { id: 'settings', label: 'Settings', icon: SettingsIcon },
];

const periodOptions = [
  { id: 'allTime', label: 'All time' },
  { id: 'thisWeek', label: 'This week' },
  { id: 'thisMonth', label: 'This month' },
  { id: 'lastWeek', label: 'Last week' },
  { id: 'lastMonth', label: 'Last month' },
  { id: 'custom', label: 'Custom' },
];

// ---------------------------------------------------------------------------
// DATE HELPERS
// ---------------------------------------------------------------------------

function pad2(n) { return String(n).padStart(2, '0'); }
function isoDate(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function startOfWeek(d) {
  const date = new Date(d);
  const day = (date.getDay() + 6) % 7; // Monday = 0
  date.setDate(date.getDate() - day);
  date.setHours(0, 0, 0, 0);
  return date;
}
function endOfWeek(d) {
  const s = startOfWeek(d);
  const e = new Date(s);
  e.setDate(s.getDate() + 6);
  e.setHours(23, 59, 59, 999);
  return e;
}
function startOfMonth(d) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d) {
  const e = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  e.setHours(23, 59, 59, 999);
  return e;
}
function fmtLabel(d) {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getPeriodRange(type, customStart, customEnd) {
  const now = new Date();
  switch (type) {
    case 'allTime':
      return { start: new Date(2000, 0, 1), end: new Date(2100, 0, 1) };
    case 'thisWeek':
      return { start: startOfWeek(now), end: endOfWeek(now) };
    case 'thisMonth':
      return { start: startOfMonth(now), end: endOfMonth(now) };
    case 'lastWeek': {
      const ref = new Date(now); ref.setDate(ref.getDate() - 7);
      return { start: startOfWeek(ref), end: endOfWeek(ref) };
    }
    case 'lastMonth': {
      const ref = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      return { start: startOfMonth(ref), end: endOfMonth(ref) };
    }
    case 'custom': {
      if (!customStart || !customEnd) return { start: startOfWeek(now), end: endOfWeek(now) };
      const s = new Date(customStart); s.setHours(0, 0, 0, 0);
      const e = new Date(customEnd); e.setHours(23, 59, 59, 999);
      return { start: s, end: e };
    }
    default:
      return { start: startOfWeek(now), end: endOfWeek(now) };
  }
}

const currency = (n) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n || 0);

// ---------------------------------------------------------------------------
// UI PRIMITIVES
// ---------------------------------------------------------------------------

function Sidebar({ active, onSelect, dispatcherName, avatarUrl, onLogout }) {
  const initials = dispatcherName
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <aside className="sidebar">
      <div className="brand">
        <Truck size={20} strokeWidth={2.2} />
        <span>SDS UZ INC</span>
      </div>
      <nav>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <React.Fragment key={item.id}>
              {item.id === 'settings' && <div className="nav-divider" />}
              <button
                className={`nav-item ${isActive ? 'nav-item--active' : ''}`}
                onClick={() => onSelect(item.id)}
              >
                <Icon size={17} strokeWidth={2} />
                <span>{item.label}</span>
              </button>
            </React.Fragment>
          );
        })}
      </nav>
      <div className="sidebar-footer">
        {avatarUrl
          ? <img src={avatarUrl} alt="" className="dispatcher-avatar" />
          : <div className="dispatcher-badge">{initials}</div>}
        <div className="sidebar-footer-info">
          <div className="dispatcher-name">{dispatcherName}</div>
          <div className="dispatcher-role">Admin</div>
        </div>
        <button className="logout-btn" onClick={onLogout} title="Log out">
          <LogOut size={15} />
        </button>
      </div>
    </aside>
  );
}

function Placeholder({ label }) {
  return (
    <div className="placeholder">
      <div className="placeholder-inner">
        <h2>{label}</h2>
        <p>This section is coming up next.</p>
      </div>
    </div>
  );
}

function PeriodSelector({ period, setPeriod, customStart, setCustomStart, customEnd, setCustomEnd, rangeLabel }) {
  return (
    <div className="period-selector">
      {period === 'custom' && (
        <div className="custom-range">
          <input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} />
          <span className="custom-range-sep">to</span>
          <input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} />
        </div>
      )}
      {period !== 'custom' && <div className="range-label">{rangeLabel}</div>}
      <select
        className="period-select"
        value={period}
        onChange={(e) => setPeriod(e.target.value)}
      >
        {periodOptions.map((opt) => (
          <option key={opt.id} value={opt.id}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}

// ---------------------------------------------------------------------------
// DASHBOARD PAGE
// ---------------------------------------------------------------------------

function Dashboard({ loads, drivers, settings }) {
  const [period, setPeriod] = useState('thisMonth');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [driverFilter, setDriverFilter] = useState('all');

  const { start, end } = useMemo(
    () => getPeriodRange(period, customStart, customEnd),
    [period, customStart, customEnd]
  );

  const rangeLabel = period === 'allTime' ? 'All time' : `${fmtLabel(start)} – ${fmtLabel(end)}`;

  const driverById = useMemo(() => {
    const map = {};
    drivers.forEach((d) => { map[d.id] = d; });
    return map;
  }, [drivers]);

  const periodLoads = useMemo(() => {
    return loads.filter((l) => {
      const d = new Date(l.pickupDate);
      const inRange = d >= start && d <= end;
      const matchesDriver = driverFilter === 'all' || l.driverId === driverFilter;
      return inRange && matchesDriver;
    });
  }, [loads, start, end, driverFilter]);

  const stats = useMemo(() => {
    let gross = 0, partial = 0;
    periodLoads.forEach((l) => {
      if (!l.isPartial) gross += l.total;
      else partial += l.total;
    });
    const monthlyGross = gross + partial;
    const fullFee = gross * (settings.fullPct / 100);
    const partialFee = partial * (settings.partialPct / 100);
    const totalEarnings = fullFee + partialFee;
    return { monthlyGross, gross, partial, fullFee, partialFee, totalEarnings };
  }, [periodLoads, settings]);

  const counts = useMemo(() => {
    let fullCount = 0, partialCount = 0;
    periodLoads.forEach((l) => {
      if (!l.isPartial) fullCount += 1;
      else partialCount += 1;
    });
    return { fullCount, partialCount };
  }, [periodLoads]);

  const topDrivers = useMemo(() => {
    const totals = {};
    periodLoads.forEach((l) => {
      totals[l.driverId] = (totals[l.driverId] || 0) + l.total;
    });
    return Object.entries(totals)
      .map(([driverId, total]) => {
        const d = driverById[driverId];
        return { name: d ? `${d.firstName} ${d.lastName}` : 'Unknown', total };
      })
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [periodLoads, driverById]);

  const driverFilterLabel = driverFilter === 'all' ? 'All drivers' : (() => {
    const d = driverById[driverFilter];
    return d ? `${d.firstName} ${d.lastName}` : 'All drivers';
  })();

  const handleExportPdf = () => {
    const rows = [
      ['Monthly Gross', currency(stats.monthlyGross)],
      ['Order', `${currency(stats.gross)} (fee ${currency(stats.fullFee)})`],
      ['Partial', `${currency(stats.partial)} (fee ${currency(stats.partialFee)})`],
      ['Total Earnings', currency(stats.totalEarnings)],
      ['Full loads', String(counts.fullCount)],
      ['Partial loads', String(counts.partialCount)],
    ];
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Dashboard Report</title>
<style>
  body { font-family: Arial, Helvetica, sans-serif; color: #111; padding: 48px; max-width: 640px; margin: 0 auto; }
  h1 { font-size: 20px; margin: 0 0 6px 0; }
  .meta { font-size: 12px; color: #555; margin-bottom: 28px; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 11px 0; border-bottom: 1px solid #ddd; font-size: 14px; }
  td:last-child { text-align: right; font-weight: 600; }
  @media print { body { padding: 24px; } }
</style></head><body>
<h1>SDS UZ INC — Dashboard Report</h1>
<div class="meta">Period: ${rangeLabel} &middot; Driver: ${driverFilterLabel} &middot; Generated ${new Date().toLocaleString('en-US')}</div>
<table>${rows.map(([l, v]) => `<tr><td>${l}</td><td>${v}</td></tr>`).join('')}</table>
<script>window.onload = function () { window.print(); };</script>
</body></html>`;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dashboard-report-${isoDate(new Date())}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p className="subtitle">Overview based on booked loads</p>
        </div>
        <div className="dashboard-header-right">
          <PeriodSelector
            period={period}
            setPeriod={setPeriod}
            customStart={customStart}
            setCustomStart={setCustomStart}
            customEnd={customEnd}
            setCustomEnd={setCustomEnd}
            rangeLabel={rangeLabel}
          />
          <button className="btn-ghost dashboard-pdf-btn" onClick={handleExportPdf}>
            <Download size={14} /> Export PDF
          </button>
        </div>
      </header>

      <div className="driver-filter-row">
        <select className="period-select" value={driverFilter} onChange={(e) => setDriverFilter(e.target.value)}>
          <option value="all">All drivers</option>
          {drivers.map((d) => (
            <option key={d.id} value={d.id}>{d.firstName} {d.lastName}</option>
          ))}
        </select>
      </div>

      <section className="stat-list">
        <div className="stat-row-item">
          <span className="stat-label">Monthly Gross</span>
          <span className="stat-value">- {currency(stats.monthlyGross)}</span>
        </div>
        <div className="stat-row-item">
          <span className="stat-label">Order</span>
          <span className="stat-value">- {currency(stats.gross)} - {currency(stats.fullFee)}</span>
        </div>
        <div className="stat-row-item">
          <span className="stat-label">Partial</span>
          <span className="stat-value">- {currency(stats.partial)} - {currency(stats.partialFee)}</span>
        </div>
        <div className="stat-row-item">
          <span className="stat-label">Total Earnings</span>
          <span className="stat-value">- {currency(stats.totalEarnings)}</span>
        </div>

        <div className="stat-divider" />

        <div className="stat-row-item">
          <span className="stat-label">Full</span>
          <span className="stat-value">- {counts.fullCount}</span>
        </div>
        <div className="stat-row-item">
          <span className="stat-label">Partial</span>
          <span className="stat-value">- {counts.partialCount}</span>
        </div>
      </section>

      <section className="panel">
        <div className="panel-header">
          <h3>Driver Performance</h3>
          <span className="panel-subtitle">Top 5 by gross, selected period</span>
        </div>
        {topDrivers.length > 0 ? (
          <div className="chart-wrap">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={topDrivers} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid stroke="#1E2C4A" vertical={false} />
                <XAxis dataKey="name" stroke="#7C8BAA" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis stroke="#7C8BAA" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#101A2E', border: '1px solid #223257', borderRadius: 6, fontSize: 12 }}
                  labelStyle={{ color: '#E8ECF6' }}
                  itemStyle={{ color: '#2ECC8F' }}
                  cursor={{ fill: 'rgba(46,204,143,0.06)' }}
                  formatter={(value) => currency(value)}
                />
                <Bar dataKey="total" fill="#2ECC8F" radius={[3, 3, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="empty-chart">No driver activity in this period yet.</div>
        )}
      </section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// DRIVERS PAGE
// ---------------------------------------------------------------------------

const emptyDriverForm = {
  firstName: '', lastName: '', truckNumber: '', type: 'company',
};

function DriverModal({ initial, onCancel, onSave }) {
  const [form, setForm] = useState(initial || emptyDriverForm);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const canSave = form.firstName.trim() && form.lastName.trim();

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3>{initial ? 'Edit Driver' : 'Add Driver'}</h3>
          <button className="icon-btn" onClick={onCancel}><X size={16} /></button>
        </div>

        <div className="modal-body">
          <div className="field-row">
            <label>First Name</label>
            <input value={form.firstName} onChange={update('firstName')} placeholder="John" />
          </div>
          <div className="field-row">
            <label>Last Name</label>
            <input value={form.lastName} onChange={update('lastName')} placeholder="Carter" />
          </div>
          <div className="field-row">
            <label>Truck Number</label>
            <input value={form.truckNumber} onChange={update('truckNumber')} placeholder="T-102" />
          </div>
          <div className="field-row">
            <label>Type</label>
            <select value={form.type} onChange={update('type')}>
              <option value="company">Company Driver</option>
              <option value="owner">Owner Operator</option>
            </select>
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onCancel}>Cancel</button>
          <button
            className="btn-primary"
            disabled={!canSave}
            onClick={() => onSave(form)}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

function Drivers({ drivers, setDrivers, logActivity, accessToken }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [saveError, setSaveError] = useState('');

  const editingDriver = drivers.find((d) => d.id === editingId) || null;

  const openAdd = () => { setEditingId(null); setModalOpen(true); setSaveError(''); };
  const openEdit = (id) => { setEditingId(id); setModalOpen(true); setConfirmDeleteId(null); setSaveError(''); };
  const closeModal = () => setModalOpen(false);

  const table = sbTable('drivers', accessToken);

  const saveDriver = async (form) => {
    const row = { first_name: form.firstName, last_name: form.lastName, truck_number: form.truckNumber, type: form.type };
    try {
      if (editingId) {
        const [updated] = await table.update(editingId, row);
        setDrivers(drivers.map((d) => (d.id === editingId
          ? { id: editingId, firstName: updated.first_name, lastName: updated.last_name, truckNumber: updated.truck_number, type: updated.type }
          : d)));
        logActivity(`Edited driver ${form.firstName} ${form.lastName}`);
      } else {
        const [created] = await table.insert(row);
        setDrivers([...drivers, { id: created.id, firstName: created.first_name, lastName: created.last_name, truckNumber: created.truck_number, type: created.type }]);
        logActivity(`Added driver ${form.firstName} ${form.lastName}`);
      }
      setModalOpen(false);
    } catch (e) {
      setSaveError(e.message || 'Could not save driver.');
    }
  };

  const deleteDriver = async (id) => {
    const d = drivers.find((x) => x.id === id);
    try {
      await table.remove(id);
      setDrivers(drivers.filter((x) => x.id !== id));
      if (d) logActivity(`Deleted driver ${d.firstName} ${d.lastName}`);
    } catch (e) {
      setSaveError(e.message || 'Could not delete driver.');
    }
    setConfirmDeleteId(null);
  };

  const typeLabel = (t) => (t === 'owner' ? 'Owner Operator' : 'Company Driver');

  const exportExcel = () => {
    const header = ['Truck #', 'First Name', 'Last Name', 'Type'];
    const rows = drivers.map((d) => [d.truckNumber || '', d.firstName, d.lastName, typeLabel(d.type)]);
    const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
    ws['!cols'] = [{ wch: 12 }, { wch: 18 }, { wch: 18 }, { wch: 18 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Drivers');
    XLSX.writeFile(wb, `drivers-${isoDate(new Date())}.xlsx`);
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Drivers</h1>
          <p className="subtitle">Manage your driver roster</p>
        </div>
        <div className="loads-header-actions">
          <button className="btn-ghost" onClick={exportExcel}><Download size={14} /> Excel</button>
          <button className="btn-primary" onClick={openAdd}><Plus size={15} /> Add Driver</button>
        </div>
      </header>

      {saveError && <div className="overdue-banner"><AlertTriangle size={14} /> {saveError}</div>}

      {drivers.length === 0 ? (
        <div className="empty-state">No drivers yet. Add your first driver to get started.</div>
      ) : (
        <div className="driver-plain-list">
          {drivers.map((d) => (
            <div className="driver-plain-row" key={d.id}>
              <div className="driver-plain-info">
                <span className="driver-plain-name">{d.firstName} {d.lastName}</span>
                <span className="driver-plain-type">{typeLabel(d.type)}</span>
              </div>

              {confirmDeleteId === d.id ? (
                <div className="confirm-row">
                  <span>Delete this driver?</span>
                  <button className="btn-ghost-sm" onClick={() => setConfirmDeleteId(null)}>Cancel</button>
                  <button className="btn-danger-sm" onClick={() => deleteDriver(d.id)}>Delete</button>
                </div>
              ) : (
                <div className="driver-plain-actions">
                  <button className="icon-btn" onClick={() => openEdit(d.id)}><Pencil size={14} /></button>
                  <button className="icon-btn" onClick={() => setConfirmDeleteId(d.id)}><Trash2 size={14} /></button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {modalOpen && (
        <DriverModal
          initial={editingDriver}
          onCancel={closeModal}
          onSave={saveDriver}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// LOADS PAGE
// ---------------------------------------------------------------------------

const statusOptions = [
  { id: 'available', label: 'Available' },
  { id: 'pickedup', label: 'Picked Up' },
  { id: 'delivered', label: 'Delivered' },
];
const statusLabel = (s) => statusOptions.find((o) => o.id === s)?.label || s;

function fmtDateInput(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${m}-${d}-${y}`;
}

function Toggle({ checked, onChange, label }) {
  return (
    <button type="button" className="toggle-row" onClick={() => onChange(!checked)}>
      <span className={`toggle-track ${checked ? 'toggle-track--on' : ''}`}>
        <span className="toggle-thumb" />
      </span>
      <span>{label}</span>
    </button>
  );
}

// Curated list of major US freight-hub cities for the From/To fields.
// Not the full USPS database — a representative set covering every state
// so dispatchers can only pick real, existing cities (search by name or zip).
const usCities = [
  { city: 'New York', state: 'NY', zip: '10001' }, { city: 'Buffalo', state: 'NY', zip: '14202' },
  { city: 'Rochester', state: 'NY', zip: '14604' }, { city: 'Syracuse', state: 'NY', zip: '13202' },
  { city: 'Albany', state: 'NY', zip: '12207' }, { city: 'Yonkers', state: 'NY', zip: '10701' },
  { city: 'Los Angeles', state: 'CA', zip: '90012' }, { city: 'San Francisco', state: 'CA', zip: '94102' },
  { city: 'San Diego', state: 'CA', zip: '92101' }, { city: 'San Jose', state: 'CA', zip: '95113' },
  { city: 'Sacramento', state: 'CA', zip: '95814' }, { city: 'Fresno', state: 'CA', zip: '93721' },
  { city: 'Long Beach', state: 'CA', zip: '90802' }, { city: 'Oakland', state: 'CA', zip: '94612' },
  { city: 'Bakersfield', state: 'CA', zip: '93301' }, { city: 'Anaheim', state: 'CA', zip: '92805' },
  { city: 'Riverside', state: 'CA', zip: '92501' }, { city: 'Stockton', state: 'CA', zip: '95202' },
  { city: 'Irvine', state: 'CA', zip: '92614' }, { city: 'Fremont', state: 'CA', zip: '94536' },
  { city: 'Santa Ana', state: 'CA', zip: '92701' }, { city: 'Chula Vista', state: 'CA', zip: '91910' },
  { city: 'Fontana', state: 'CA', zip: '92335' }, { city: 'Modesto', state: 'CA', zip: '95354' },
  { city: 'Chicago', state: 'IL', zip: '60601' }, { city: 'Springfield', state: 'IL', zip: '62701' },
  { city: 'Naperville', state: 'IL', zip: '60540' }, { city: 'Rockford', state: 'IL', zip: '61101' },
  { city: 'Peoria', state: 'IL', zip: '61602' },
  { city: 'Houston', state: 'TX', zip: '77002' }, { city: 'Dallas', state: 'TX', zip: '75201' },
  { city: 'San Antonio', state: 'TX', zip: '78205' }, { city: 'Austin', state: 'TX', zip: '78701' },
  { city: 'Fort Worth', state: 'TX', zip: '76102' }, { city: 'El Paso', state: 'TX', zip: '79901' },
  { city: 'Arlington', state: 'TX', zip: '76010' }, { city: 'Corpus Christi', state: 'TX', zip: '78401' },
  { city: 'Plano', state: 'TX', zip: '75023' }, { city: 'Laredo', state: 'TX', zip: '78040' },
  { city: 'Lubbock', state: 'TX', zip: '79401' }, { city: 'Amarillo', state: 'TX', zip: '79101' },
  { city: 'McAllen', state: 'TX', zip: '78501' }, { city: 'Waco', state: 'TX', zip: '76701' },
  { city: 'Beaumont', state: 'TX', zip: '77701' },
  { city: 'Phoenix', state: 'AZ', zip: '85003' }, { city: 'Tucson', state: 'AZ', zip: '85701' },
  { city: 'Mesa', state: 'AZ', zip: '85201' }, { city: 'Chandler', state: 'AZ', zip: '85224' },
  { city: 'Scottsdale', state: 'AZ', zip: '85251' },
  { city: 'Philadelphia', state: 'PA', zip: '19102' }, { city: 'Pittsburgh', state: 'PA', zip: '15222' },
  { city: 'Allentown', state: 'PA', zip: '18101' }, { city: 'Erie', state: 'PA', zip: '16501' },
  { city: 'Harrisburg', state: 'PA', zip: '17101' },
  { city: 'Jacksonville', state: 'FL', zip: '32202' }, { city: 'Miami', state: 'FL', zip: '33131' },
  { city: 'Tampa', state: 'FL', zip: '33602' }, { city: 'Orlando', state: 'FL', zip: '32801' },
  { city: 'Fort Lauderdale', state: 'FL', zip: '33301' }, { city: 'St. Petersburg', state: 'FL', zip: '33701' },
  { city: 'Tallahassee', state: 'FL', zip: '32301' },
  { city: 'Columbus', state: 'OH', zip: '43215' }, { city: 'Cleveland', state: 'OH', zip: '44113' },
  { city: 'Cincinnati', state: 'OH', zip: '45202' }, { city: 'Toledo', state: 'OH', zip: '43604' },
  { city: 'Akron', state: 'OH', zip: '44308' }, { city: 'Dayton', state: 'OH', zip: '45402' },
  { city: 'Charlotte', state: 'NC', zip: '28202' }, { city: 'Raleigh', state: 'NC', zip: '27601' },
  { city: 'Greensboro', state: 'NC', zip: '27401' }, { city: 'Durham', state: 'NC', zip: '27701' },
  { city: 'Winston-Salem', state: 'NC', zip: '27101' },
  { city: 'Indianapolis', state: 'IN', zip: '46204' }, { city: 'Fort Wayne', state: 'IN', zip: '46802' },
  { city: 'Evansville', state: 'IN', zip: '47708' },
  { city: 'Seattle', state: 'WA', zip: '98101' }, { city: 'Spokane', state: 'WA', zip: '99201' },
  { city: 'Tacoma', state: 'WA', zip: '98402' }, { city: 'Vancouver', state: 'WA', zip: '98660' },
  { city: 'Bellevue', state: 'WA', zip: '98004' },
  { city: 'Denver', state: 'CO', zip: '80202' }, { city: 'Colorado Springs', state: 'CO', zip: '80903' },
  { city: 'Aurora', state: 'CO', zip: '80010' }, { city: 'Fort Collins', state: 'CO', zip: '80521' },
  { city: 'Boulder', state: 'CO', zip: '80301' },
  { city: 'Washington', state: 'DC', zip: '20001' },
  { city: 'Boston', state: 'MA', zip: '02108' }, { city: 'Worcester', state: 'MA', zip: '01608' },
  { city: 'Springfield', state: 'MA', zip: '01103' }, { city: 'Cambridge', state: 'MA', zip: '02138' },
  { city: 'El Paso', state: 'TX', zip: '79901' },
  { city: 'Nashville', state: 'TN', zip: '37203' }, { city: 'Memphis', state: 'TN', zip: '38103' },
  { city: 'Knoxville', state: 'TN', zip: '37902' }, { city: 'Chattanooga', state: 'TN', zip: '37402' },
  { city: 'Detroit', state: 'MI', zip: '48226' }, { city: 'Grand Rapids', state: 'MI', zip: '49503' },
  { city: 'Lansing', state: 'MI', zip: '48933' }, { city: 'Ann Arbor', state: 'MI', zip: '48104' },
  { city: 'Oklahoma City', state: 'OK', zip: '73102' }, { city: 'Tulsa', state: 'OK', zip: '74103' },
  { city: 'Norman', state: 'OK', zip: '73069' },
  { city: 'Portland', state: 'OR', zip: '97201' }, { city: 'Eugene', state: 'OR', zip: '97401' },
  { city: 'Salem', state: 'OR', zip: '97301' },
  { city: 'Las Vegas', state: 'NV', zip: '89101' }, { city: 'Reno', state: 'NV', zip: '89501' },
  { city: 'Henderson', state: 'NV', zip: '89002' },
  { city: 'Louisville', state: 'KY', zip: '40202' }, { city: 'Lexington', state: 'KY', zip: '40507' },
  { city: 'Baltimore', state: 'MD', zip: '21201' }, { city: 'Annapolis', state: 'MD', zip: '21401' },
  { city: 'Milwaukee', state: 'WI', zip: '53202' }, { city: 'Madison', state: 'WI', zip: '53703' },
  { city: 'Green Bay', state: 'WI', zip: '54301' },
  { city: 'Albuquerque', state: 'NM', zip: '87102' }, { city: 'Santa Fe', state: 'NM', zip: '87501' },
  { city: 'Kansas City', state: 'MO', zip: '64106' }, { city: 'St. Louis', state: 'MO', zip: '63101' },
  { city: 'Springfield', state: 'MO', zip: '65806' }, { city: 'Columbia', state: 'MO', zip: '65201' },
  { city: 'Atlanta', state: 'GA', zip: '30303' }, { city: 'Savannah', state: 'GA', zip: '31401' },
  { city: 'Augusta', state: 'GA', zip: '30901' }, { city: 'Columbus', state: 'GA', zip: '31901' },
  { city: 'Omaha', state: 'NE', zip: '68102' }, { city: 'Lincoln', state: 'NE', zip: '68508' },
  { city: 'Raleigh', state: 'NC', zip: '27601' },
  { city: 'Miami', state: 'FL', zip: '33131' },
  { city: 'Minneapolis', state: 'MN', zip: '55401' }, { city: 'Saint Paul', state: 'MN', zip: '55102' },
  { city: 'Rochester', state: 'MN', zip: '55901' },
  { city: 'Tulsa', state: 'OK', zip: '74103' },
  { city: 'Wichita', state: 'KS', zip: '67202' }, { city: 'Topeka', state: 'KS', zip: '66603' },
  { city: 'Overland Park', state: 'KS', zip: '66210' },
  { city: 'New Orleans', state: 'LA', zip: '70112' }, { city: 'Baton Rouge', state: 'LA', zip: '70801' },
  { city: 'Shreveport', state: 'LA', zip: '71101' }, { city: 'Lafayette', state: 'LA', zip: '70501' },
  { city: 'Honolulu', state: 'HI', zip: '96813' },
  { city: 'Anchorage', state: 'AK', zip: '99501' },
  { city: 'Salt Lake City', state: 'UT', zip: '84101' }, { city: 'Provo', state: 'UT', zip: '84601' },
  { city: 'West Valley City', state: 'UT', zip: '84119' },
  { city: 'Richmond', state: 'VA', zip: '23219' }, { city: 'Virginia Beach', state: 'VA', zip: '23451' },
  { city: 'Norfolk', state: 'VA', zip: '23510' }, { city: 'Arlington', state: 'VA', zip: '22201' },
  { city: 'Alexandria', state: 'VA', zip: '22314' }, { city: 'Newport News', state: 'VA', zip: '23601' },
  { city: 'Birmingham', state: 'AL', zip: '35203' }, { city: 'Montgomery', state: 'AL', zip: '36104' },
  { city: 'Huntsville', state: 'AL', zip: '35801' }, { city: 'Mobile', state: 'AL', zip: '36602' },
  { city: 'Little Rock', state: 'AR', zip: '72201' }, { city: 'Fayetteville', state: 'AR', zip: '72701' },
  { city: 'Hartford', state: 'CT', zip: '06103' }, { city: 'New Haven', state: 'CT', zip: '06510' },
  { city: 'Bridgeport', state: 'CT', zip: '06604' }, { city: 'Stamford', state: 'CT', zip: '06901' },
  { city: 'Wilmington', state: 'DE', zip: '19801' }, { city: 'Dover', state: 'DE', zip: '19901' },
  { city: 'Boise', state: 'ID', zip: '83702' },
  { city: 'Des Moines', state: 'IA', zip: '50309' }, { city: 'Cedar Rapids', state: 'IA', zip: '52401' },
  { city: 'Portland', state: 'ME', zip: '04101' }, { city: 'Augusta', state: 'ME', zip: '04330' },
  { city: 'Jackson', state: 'MS', zip: '39201' }, { city: 'Gulfport', state: 'MS', zip: '39501' },
  { city: 'Billings', state: 'MT', zip: '59101' }, { city: 'Helena', state: 'MT', zip: '59601' },
  { city: 'Manchester', state: 'NH', zip: '03101' }, { city: 'Concord', state: 'NH', zip: '03301' },
  { city: 'Newark', state: 'NJ', zip: '07102' }, { city: 'Jersey City', state: 'NJ', zip: '07302' },
  { city: 'Trenton', state: 'NJ', zip: '08608' }, { city: 'Atlantic City', state: 'NJ', zip: '08401' },
  { city: 'Fargo', state: 'ND', zip: '58102' }, { city: 'Bismarck', state: 'ND', zip: '58501' },
  { city: 'Providence', state: 'RI', zip: '02903' },
  { city: 'Columbia', state: 'SC', zip: '29201' }, { city: 'Charleston', state: 'SC', zip: '29401' },
  { city: 'Greenville', state: 'SC', zip: '29601' },
  { city: 'Sioux Falls', state: 'SD', zip: '57104' }, { city: 'Rapid City', state: 'SD', zip: '57701' },
  { city: 'Burlington', state: 'VT', zip: '05401' }, { city: 'Montpelier', state: 'VT', zip: '05602' },
  { city: 'Charleston', state: 'WV', zip: '25301' }, { city: 'Huntington', state: 'WV', zip: '25701' },
  { city: 'Cheyenne', state: 'WY', zip: '82001' }, { city: 'Casper', state: 'WY', zip: '82601' },
];

// Full state name -> USPS abbreviation, used to normalize the extended list below.
const STATE_ABBR = {
  Alabama: 'AL', Alaska: 'AK', Arizona: 'AZ', Arkansas: 'AR', California: 'CA',
  Colorado: 'CO', Connecticut: 'CT', Delaware: 'DE', Florida: 'FL', Georgia: 'GA',
  Hawaii: 'HI', Idaho: 'ID', Illinois: 'IL', Indiana: 'IN', Iowa: 'IA',
  Kansas: 'KS', Kentucky: 'KY', Louisiana: 'LA', Maine: 'ME', Maryland: 'MD',
  Massachusetts: 'MA', Michigan: 'MI', Minnesota: 'MN', Mississippi: 'MS',
  Missouri: 'MO', Montana: 'MT', Nebraska: 'NE', Nevada: 'NV', 'New Hampshire': 'NH',
  'New Jersey': 'NJ', 'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC',
  'North Dakota': 'ND', Ohio: 'OH', Oklahoma: 'OK', Oregon: 'OR', Pennsylvania: 'PA',
  'Rhode Island': 'RI', 'South Carolina': 'SC', 'South Dakota': 'SD', Tennessee: 'TN',
  Texas: 'TX', Utah: 'UT', Vermont: 'VT', Virginia: 'VA', Washington: 'WA',
  'West Virginia': 'WV', Wisconsin: 'WI', Wyoming: 'WY', 'District of Columbia': 'DC',
};

// Extended city list (no ZIP on file) sourced from a public US-cities dataset —
// broadens name search far beyond the ~150 hub cities above, covering every
// state. ZIP search only works for the hub list above; see chat for why.
const usCitiesExtra = [
  { city: 'Abbeville', state: 'Louisiana' }, { city: 'Aberdeen', state: 'Maryland' },
  { city: 'Aberdeen', state: 'Mississippi' }, { city: 'Aberdeen', state: 'South Dakota' },
  { city: 'Aberdeen', state: 'Washington' }, { city: 'Abilene', state: 'Texas' },
  { city: 'Abilene', state: 'Kansas' }, { city: 'Abingdon', state: 'Virginia' },
  { city: 'Abington', state: 'Massachusetts' }, { city: 'Absecon', state: 'New Jersey' },
  { city: 'Accokeek', state: 'Maryland' }, { city: 'Acton', state: 'Massachusetts' },
  { city: 'Acushnet', state: 'Massachusetts' }, { city: 'Acworth', state: 'Georgia' },
  { city: 'Ada', state: 'Oklahoma' }, { city: 'Adams', state: 'Massachusetts' },
  { city: 'Addison', state: 'Illinois' }, { city: 'Addison', state: 'Texas' },
  { city: 'Adelanto', state: 'California' }, { city: 'Adelphi', state: 'Maryland' },
  { city: 'Adrian', state: 'Michigan' }, { city: 'Affton', state: 'Missouri' },
  { city: 'Agawam', state: 'Massachusetts' }, { city: 'Agoura Hills', state: 'California' },
  { city: 'Ahuimanu', state: 'Hawaii' }, { city: 'Aiea', state: 'Hawaii' },
  { city: 'Aiken', state: 'South Carolina' }, { city: 'Air Force Academy', state: 'Colorado' },
  { city: 'Airmont', state: 'New York' }, { city: 'Akron', state: 'Ohio' },
  { city: 'Alabaster', state: 'Alabama' }, { city: 'Alachua', state: 'Florida' },
  { city: 'Alameda', state: 'California' }, { city: 'Alamo', state: 'California' },
  { city: 'Alamo', state: 'Texas' }, { city: 'Alamo Heights', state: 'Texas' },
  { city: 'Alamogordo', state: 'New Mexico' }, { city: 'Alamosa', state: 'Colorado' },
  { city: 'Albany', state: 'Georgia' }, { city: 'Albany', state: 'California' },
  { city: 'Albany', state: 'New York' }, { city: 'Albany', state: 'Oregon' },
  { city: 'Albemarle', state: 'North Carolina' }, { city: 'Albert Lea', state: 'Minnesota' },
  { city: 'Albertville', state: 'Alabama' }, { city: 'Albion', state: 'Michigan' },
  { city: 'Albion', state: 'New York' }, { city: 'Albuquerque', state: 'New Mexico' },
  { city: 'Alcoa', state: 'Tennessee' }, { city: 'Alden', state: 'New York' },
  { city: 'Alderwood Manor', state: 'Washington' }, { city: 'Aldine', state: 'Texas' },
  { city: 'Alexander City', state: 'Alabama' }, { city: 'Alexandria', state: 'Indiana' },
  { city: 'Alexandria', state: 'Minnesota' }, { city: 'Alexandria', state: 'Kentucky' },
  { city: 'Alexandria', state: 'Louisiana' }, { city: 'Alexandria', state: 'Virginia' },
  { city: 'Algonquin', state: 'Illinois' }, { city: 'Alhambra', state: 'California' },
  { city: 'Alice', state: 'Texas' }, { city: 'Aliquippa', state: 'Pennsylvania' },
  { city: 'Aliso Viejo', state: 'California' }, { city: 'Allegany', state: 'New York' },
  { city: 'Allen', state: 'Texas' }, { city: 'Allen Park', state: 'Michigan' },
  { city: 'Allendale', state: 'Michigan' }, { city: 'Allendale', state: 'New Jersey' },
  { city: 'Allentown', state: 'Pennsylvania' }, { city: 'Alliance', state: 'Ohio' },
  { city: 'Alliance', state: 'Nebraska' }, { city: 'Allouez', state: 'Wisconsin' },
  { city: 'Alma', state: 'Michigan' }, { city: 'Aloha', state: 'Oregon' },
  { city: 'Alondra Park', state: 'California' }, { city: 'Alpena', state: 'Michigan' },
  { city: 'Alpharetta', state: 'Georgia' }, { city: 'Alpine', state: 'California' },
  { city: 'Alpine', state: 'Utah' }, { city: 'Alsip', state: 'Illinois' },
  { city: 'Alta Sierra', state: 'California' }, { city: 'Altadena', state: 'California' },
  { city: 'Altamont', state: 'Oregon' }, { city: 'Altamont', state: 'New York' },
  { city: 'Altamonte Springs', state: 'Florida' }, { city: 'Alton', state: 'Illinois' },
  { city: 'Altoona', state: 'Iowa' }, { city: 'Altoona', state: 'Pennsylvania' },
  { city: 'Altoona', state: 'Wisconsin' }, { city: 'Altus', state: 'Oklahoma' },
  { city: 'Alum Rock', state: 'California' }, { city: 'Alvin', state: 'Texas' },
  { city: 'Amarillo', state: 'Texas' }, { city: 'Ambler', state: 'Pennsylvania' },
  { city: 'Ambridge', state: 'Pennsylvania' }, { city: 'American Canyon', state: 'California' },
  { city: 'American Fork', state: 'Utah' }, { city: 'Americus', state: 'Georgia' },
  { city: 'Ames', state: 'Iowa' }, { city: 'Amesbury', state: 'Massachusetts' },
  { city: 'Amherst', state: 'New Hampshire' }, { city: 'Amherst', state: 'Massachusetts' },
  { city: 'Amherst', state: 'Ohio' }, { city: 'Amherst', state: 'New York' },
  { city: 'Amityville', state: 'New York' }, { city: 'Ammon', state: 'Idaho' },
  { city: 'Amory', state: 'Mississippi' }, { city: 'Amsterdam', state: 'New York' },
  { city: 'Anacortes', state: 'Washington' }, { city: 'Anadarko', state: 'Oklahoma' },
  { city: 'Anaheim', state: 'California' }, { city: 'Anchorage', state: 'Alaska' },
  { city: 'Andalusia', state: 'Alabama' }, { city: 'Anderson', state: 'California' },
  { city: 'Anderson', state: 'Indiana' }, { city: 'Anderson', state: 'South Carolina' },
  { city: 'Andover', state: 'Minnesota' }, { city: 'Andover', state: 'Massachusetts' },
  { city: 'Andover', state: 'Kansas' }, { city: 'Andrews', state: 'Texas' },
  { city: 'Angleton', state: 'Texas' }, { city: 'Angola', state: 'Indiana' },
  { city: 'Ankeny', state: 'Iowa' }, { city: 'Ann Arbor', state: 'Michigan' },
  { city: 'Annandale', state: 'Virginia' }, { city: 'Annapolis', state: 'Maryland' },
  { city: 'Anniston', state: 'Alabama' }, { city: 'Anoka', state: 'Minnesota' },
  { city: 'Ansonia', state: 'Connecticut' }, { city: 'Anthony', state: 'New Mexico' },
  { city: 'Antigo', state: 'Wisconsin' }, { city: 'Antioch', state: 'Illinois' },
  { city: 'Antioch', state: 'California' }, { city: 'Apache Junction', state: 'Arizona' },
  { city: 'Apex', state: 'North Carolina' }, { city: 'Apopka', state: 'Florida' },
  { city: 'Apple Valley', state: 'California' }, { city: 'Apple Valley', state: 'Minnesota' },
  { city: 'Appleton', state: 'Wisconsin' }, { city: 'Aptos', state: 'California' },
  { city: 'Arab', state: 'Alabama' }, { city: 'Aransas Pass', state: 'Texas' },
  { city: 'Arbutus', state: 'Maryland' }, { city: 'Arcadia', state: 'California' },
  { city: 'Arcadia', state: 'Florida' }, { city: 'Arcata', state: 'California' },
  { city: 'Archdale', state: 'North Carolina' }, { city: 'Arden Hills', state: 'Minnesota' },
  { city: 'Ardmore', state: 'Oklahoma' }, { city: 'Ardmore', state: 'Pennsylvania' },
  { city: 'Arkadelphia', state: 'Arkansas' }, { city: 'Arlington', state: 'Massachusetts' },
  { city: 'Arlington', state: 'Texas' }, { city: 'Arlington', state: 'New York' },
  { city: 'Arlington', state: 'Virginia' }, { city: 'Arlington', state: 'Washington' },
  { city: 'Arlington Heights', state: 'Illinois' }, { city: 'Arnold', state: 'Missouri' },
  { city: 'Arnold', state: 'Maryland' }, { city: 'Arroyo Grande', state: 'California' },
  { city: 'Artesia', state: 'California' }, { city: 'Artesia', state: 'New Mexico' },
  { city: 'Arvada', state: 'Colorado' }, { city: 'Arvin', state: 'California' },
  { city: 'Asbury Park', state: 'New Jersey' }, { city: 'Asheboro', state: 'North Carolina' },
  { city: 'Asheville', state: 'North Carolina' }, { city: 'Ashland', state: 'Oregon' },
  { city: 'Ashland', state: 'Ohio' }, { city: 'Ashland', state: 'Virginia' },
  { city: 'Ashland', state: 'Wisconsin' }, { city: 'Ashland', state: 'Massachusetts' },
  { city: 'Ashland', state: 'Kentucky' }, { city: 'Ashtabula', state: 'Ohio' },
  { city: 'Astoria', state: 'Oregon' }, { city: 'Atascadero', state: 'California' },
  { city: 'Atchison', state: 'Kansas' }, { city: 'Athens', state: 'Alabama' },
  { city: 'Athens', state: 'Texas' }, { city: 'Athens', state: 'Tennessee' },
  { city: 'Athens', state: 'Ohio' }, { city: 'Atherton', state: 'California' },
  { city: 'Atlanta', state: 'Georgia' }, { city: 'Atlantic', state: 'Iowa' },
  { city: 'Atlantic Beach', state: 'Florida' }, { city: 'Atlantic City', state: 'New Jersey' },
  { city: 'Atmore', state: 'Alabama' }, { city: 'Attalla', state: 'Alabama' },
  { city: 'Attica', state: 'New York' }, { city: 'Attleboro', state: 'Massachusetts' },
  { city: 'Atwater', state: 'California' }, { city: 'Auburn', state: 'California' },
  { city: 'Auburn', state: 'Alabama' }, { city: 'Auburn', state: 'Georgia' },
  { city: 'Auburn', state: 'Indiana' }, { city: 'Auburn', state: 'Massachusetts' },
  { city: 'Auburn', state: 'Maine' }, { city: 'Auburn', state: 'New York' },
  { city: 'Auburn', state: 'Washington' }, { city: 'Auburn Hills', state: 'Michigan' },
  { city: 'Auburndale', state: 'Florida' }, { city: 'Audubon', state: 'New Jersey' },
  { city: 'Augusta', state: 'Maine' }, { city: 'Augusta', state: 'Kansas' },
  { city: 'Aurora', state: 'Illinois' }, { city: 'Aurora', state: 'Colorado' },
  { city: 'Aurora', state: 'Missouri' }, { city: 'Aurora', state: 'New York' },
  { city: 'Aurora', state: 'Ohio' }, { city: 'Austin', state: 'Texas' },
  { city: 'Austin', state: 'Minnesota' }, { city: 'Austintown', state: 'Ohio' },
  { city: 'Avenal', state: 'California' }, { city: 'Aventura', state: 'Florida' },
  { city: 'Avon', state: 'Connecticut' }, { city: 'Avon', state: 'Indiana' },
  { city: 'Avon', state: 'Ohio' }, { city: 'Avon', state: 'New York' },
  { city: 'Avon Lake', state: 'Ohio' }, { city: 'Avon Park', state: 'Florida' },
  { city: 'Avondale', state: 'Arizona' }, { city: 'Ayer', state: 'Massachusetts' },
  { city: 'Azle', state: 'Texas' }, { city: 'Aztec', state: 'New Mexico' },
  { city: 'Azusa', state: 'California' }, { city: 'Babylon', state: 'New York' },
  { city: 'Bainbridge', state: 'Georgia' }, { city: 'Bainbridge Island', state: 'Washington' },
  { city: 'Baker', state: 'Louisiana' }, { city: 'Bakersfield', state: 'California' },
  { city: 'Balch Springs', state: 'Texas' }, { city: 'Baldwin', state: 'Pennsylvania' },
  { city: 'Baldwin', state: 'New York' }, { city: 'Baldwin Park', state: 'California' },
  { city: 'Baldwinsville', state: 'New York' }, { city: 'Ballwin', state: 'Missouri' },
  { city: 'Baltimore', state: 'Maryland' }, { city: 'Bangor', state: 'Maine' },
  { city: 'Banning', state: 'California' }, { city: 'Baraboo', state: 'Wisconsin' },
  { city: 'Barberton', state: 'Ohio' }, { city: 'Bardstown', state: 'Kentucky' },
  { city: 'Barnstable Town', state: 'Massachusetts' }, { city: 'Barre', state: 'Vermont' },
  { city: 'Barrington', state: 'Rhode Island' }, { city: 'Barrington', state: 'New Jersey' },
  { city: 'Barrington', state: 'New Hampshire' }, { city: 'Barrington', state: 'Illinois' },
  { city: 'Barstow', state: 'California' }, { city: 'Bartlesville', state: 'Oklahoma' },
  { city: 'Bartlett', state: 'Illinois' }, { city: 'Bartlett', state: 'Tennessee' },
  { city: 'Bartow', state: 'Florida' }, { city: 'Bastrop', state: 'Louisiana' },
  { city: 'Batavia', state: 'Illinois' }, { city: 'Batavia', state: 'New York' },
  { city: 'Batesville', state: 'Mississippi' }, { city: 'Batesville', state: 'Indiana' },
  { city: 'Batesville', state: 'Arkansas' }, { city: 'Bath', state: 'Maine' },
  { city: 'Bath', state: 'New York' }, { city: 'Baton Rouge', state: 'Louisiana' },
  { city: 'Battle Creek', state: 'Michigan' }, { city: 'Battle Ground', state: 'Washington' },
  { city: 'Bay City', state: 'Texas' }, { city: 'Bay City', state: 'Michigan' },
  { city: 'Bay Shore', state: 'New York' }, { city: 'Bay Village', state: 'Ohio' },
  { city: 'Bayonne', state: 'New Jersey' }, { city: 'Baytown', state: 'Texas' },
  { city: 'Beachwood', state: 'Ohio' }, { city: 'Beacon', state: 'New York' },
  { city: 'Beatrice', state: 'Nebraska' }, { city: 'Beaufort', state: 'South Carolina' },
  { city: 'Beaumont', state: 'Texas' }, { city: 'Beaumont', state: 'California' },
  { city: 'Beaver Dam', state: 'Wisconsin' }, { city: 'Beaver Falls', state: 'Pennsylvania' },
  { city: 'Beavercreek', state: 'Ohio' }, { city: 'Beaverton', state: 'Oregon' },
  { city: 'Beckley', state: 'West Virginia' }, { city: 'Bedford', state: 'Virginia' },
  { city: 'Bedford', state: 'Texas' }, { city: 'Bedford', state: 'Ohio' },
  { city: 'Bedford', state: 'New Hampshire' }, { city: 'Bedford', state: 'Indiana' },
  { city: 'Beech Grove', state: 'Indiana' }, { city: 'Beeville', state: 'Texas' },
  { city: 'Bel Air', state: 'Maryland' }, { city: 'Belen', state: 'New Mexico' },
  { city: 'Belfast', state: 'Maine' }, { city: 'Bell', state: 'California' },
  { city: 'Bell Gardens', state: 'California' }, { city: 'Bellaire', state: 'Texas' },
  { city: 'Belle Glade', state: 'Florida' }, { city: 'Bellefontaine', state: 'Ohio' },
  { city: 'Belleville', state: 'New Jersey' }, { city: 'Belleville', state: 'Illinois' },
  { city: 'Bellevue', state: 'Kentucky' }, { city: 'Bellevue', state: 'Nebraska' },
  { city: 'Bellevue', state: 'Ohio' }, { city: 'Bellevue', state: 'Washington' },
  { city: 'Bellflower', state: 'California' }, { city: 'Bellingham', state: 'Massachusetts' },
  { city: 'Bellingham', state: 'Washington' }, { city: 'Bellmawr', state: 'New Jersey' },
  { city: 'Bellwood', state: 'Illinois' }, { city: 'Belmont', state: 'Massachusetts' },
  { city: 'Belmont', state: 'North Carolina' }, { city: 'Belmont', state: 'California' },
  { city: 'Beloit', state: 'Wisconsin' }, { city: 'Belton', state: 'Missouri' },
  { city: 'Belton', state: 'Texas' }, { city: 'Beltsville', state: 'Maryland' },
  { city: 'Belvidere', state: 'Illinois' }, { city: 'Bemidji', state: 'Minnesota' },
  { city: 'Benbrook', state: 'Texas' }, { city: 'Bend', state: 'Oregon' },
  { city: 'Benicia', state: 'California' }, { city: 'Bennington', state: 'Vermont' },
  { city: 'Bensenville', state: 'Illinois' }, { city: 'Benton', state: 'Arkansas' },
  { city: 'Benton Harbor', state: 'Michigan' }, { city: 'Bentonville', state: 'Arkansas' },
  { city: 'Berea', state: 'Kentucky' }, { city: 'Berea', state: 'Ohio' },
  { city: 'Bergenfield', state: 'New Jersey' }, { city: 'Berkeley', state: 'Missouri' },
  { city: 'Berkeley', state: 'California' }, { city: 'Berkley', state: 'Michigan' },
  { city: 'Berlin', state: 'Connecticut' }, { city: 'Berlin', state: 'New Jersey' },
  { city: 'Berlin', state: 'New Hampshire' }, { city: 'Bernalillo', state: 'New Mexico' },
  { city: 'Berwick', state: 'Pennsylvania' }, { city: 'Berwyn', state: 'Illinois' },
  { city: 'Bessemer', state: 'Alabama' }, { city: 'Bethany', state: 'Oklahoma' },
  { city: 'Bethel', state: 'Connecticut' }, { city: 'Bethel Park', state: 'Pennsylvania' },
  { city: 'Bethesda', state: 'Maryland' }, { city: 'Bethlehem', state: 'Pennsylvania' },
  { city: 'Bettendorf', state: 'Iowa' }, { city: 'Beverly', state: 'Massachusetts' },
  { city: 'Beverly Hills', state: 'California' }, { city: 'Bexley', state: 'Ohio' },
  { city: 'Biddeford', state: 'Maine' }, { city: 'Big Spring', state: 'Texas' },
  { city: 'Billerica', state: 'Massachusetts' }, { city: 'Billings', state: 'Montana' },
  { city: 'Biloxi', state: 'Mississippi' }, { city: 'Binghamton', state: 'New York' },
  { city: 'Birmingham', state: 'Michigan' }, { city: 'Birmingham', state: 'Alabama' },
  { city: 'Bisbee', state: 'Arizona' }, { city: 'Bismarck', state: 'North Dakota' },
  { city: 'Blacksburg', state: 'Virginia' }, { city: 'Bloomfield', state: 'New Jersey' },
  { city: 'Bloomfield', state: 'New Mexico' }, { city: 'Bloomfield', state: 'Connecticut' },
  { city: 'Bloomingdale', state: 'Illinois' }, { city: 'Bloomington', state: 'Illinois' },
  { city: 'Bloomington', state: 'Indiana' }, { city: 'Bloomington', state: 'California' },
  { city: 'Bloomington', state: 'Minnesota' }, { city: 'Bloomsburg', state: 'Pennsylvania' },
  { city: 'Blue Ash', state: 'Ohio' }, { city: 'Blue Island', state: 'Illinois' },
  { city: 'Blue Springs', state: 'Missouri' }, { city: 'Bluefield', state: 'West Virginia' },
  { city: 'Blytheville', state: 'Arkansas' }, { city: 'Boardman', state: 'Ohio' },
  { city: 'Boca Raton', state: 'Florida' }, { city: 'Boerne', state: 'Texas' },
  { city: 'Bogalusa', state: 'Louisiana' }, { city: 'Boise', state: 'Idaho' },
  { city: 'Bolingbrook', state: 'Illinois' }, { city: 'Bolivar', state: 'Missouri' },
  { city: 'Bonham', state: 'Texas' }, { city: 'Bonita Springs', state: 'Florida' },
  { city: 'Bonner Springs', state: 'Kansas' }, { city: 'Bonney Lake', state: 'Washington' },
  { city: 'Boone', state: 'Iowa' }, { city: 'Boone', state: 'North Carolina' },
  { city: 'Boonton', state: 'New Jersey' }, { city: 'Borger', state: 'Texas' },
  { city: 'Bossier City', state: 'Louisiana' }, { city: 'Boston', state: 'Massachusetts' },
  { city: 'Bothell', state: 'Washington' }, { city: 'Boulder', state: 'Colorado' },
  { city: 'Boulder City', state: 'Nevada' }, { city: 'Bountiful', state: 'Utah' },
  { city: 'Bourbonnais', state: 'Illinois' }, { city: 'Bourne', state: 'Massachusetts' },
  { city: 'Bowie', state: 'Maryland' }, { city: 'Bowling Green', state: 'Kentucky' },
  { city: 'Bowling Green', state: 'Ohio' }, { city: 'Boynton Beach', state: 'Florida' },
  { city: 'Bozeman', state: 'Montana' }, { city: 'Bradenton', state: 'Florida' },
  { city: 'Bradford', state: 'Pennsylvania' }, { city: 'Bradley', state: 'Illinois' },
  { city: 'Brainerd', state: 'Minnesota' }, { city: 'Braintree', state: 'Massachusetts' },
  { city: 'Brandon', state: 'Mississippi' }, { city: 'Brandon', state: 'Florida' },
  { city: 'Branford', state: 'Connecticut' }, { city: 'Branson', state: 'Missouri' },
  { city: 'Brattleboro', state: 'Vermont' }, { city: 'Brawley', state: 'California' },
  { city: 'Brazil', state: 'Indiana' }, { city: 'Brea', state: 'California' },
  { city: 'Brecksville', state: 'Ohio' }, { city: 'Bremerton', state: 'Washington' },
  { city: 'Brenham', state: 'Texas' }, { city: 'Brentwood', state: 'California' },
  { city: 'Brentwood', state: 'New York' }, { city: 'Brentwood', state: 'Missouri' },
  { city: 'Brentwood', state: 'Tennessee' }, { city: 'Brevard', state: 'North Carolina' },
  { city: 'Brewer', state: 'Maine' }, { city: 'Bridgeport', state: 'West Virginia' },
  { city: 'Bridgeport', state: 'Connecticut' }, { city: 'Bridgeton', state: 'Missouri' },
  { city: 'Bridgeton', state: 'New Jersey' }, { city: 'Bridgeview', state: 'Illinois' },
  { city: 'Bridgewater', state: 'Massachusetts' }, { city: 'Brigham City', state: 'Utah' },
  { city: 'Brighton', state: 'Michigan' }, { city: 'Brighton', state: 'Colorado' },
  { city: 'Bristol', state: 'Connecticut' }, { city: 'Bristol', state: 'Rhode Island' },
  { city: 'Bristol', state: 'Tennessee' }, { city: 'Bristol', state: 'Virginia' },
  { city: 'Bristol', state: 'Pennsylvania' }, { city: 'Broadview Heights', state: 'Ohio' },
  { city: 'Brockton', state: 'Massachusetts' }, { city: 'Broken Arrow', state: 'Oklahoma' },
  { city: 'Brookfield', state: 'Wisconsin' }, { city: 'Brookhaven', state: 'Mississippi' },
  { city: 'Brookings', state: 'South Dakota' }, { city: 'Brookline', state: 'Massachusetts' },
  { city: 'Brooklyn Center', state: 'Minnesota' }, { city: 'Brooklyn Park', state: 'Minnesota' },
  { city: 'Brooksville', state: 'Florida' }, { city: 'Broomfield', state: 'Colorado' },
  { city: 'Brownsburg', state: 'Indiana' }, { city: 'Brownsville', state: 'Texas' },
  { city: 'Brownsville', state: 'Tennessee' }, { city: 'Brownwood', state: 'Texas' },
  { city: 'Brunswick', state: 'Maine' }, { city: 'Brunswick', state: 'Georgia' },
  { city: 'Brunswick', state: 'Ohio' }, { city: 'Bryan', state: 'Texas' },
  { city: 'Bryan', state: 'Ohio' }, { city: 'Buckeye', state: 'Arizona' },
  { city: 'Buena Park', state: 'California' }, { city: 'Buffalo', state: 'Minnesota' },
  { city: 'Buffalo', state: 'New York' }, { city: 'Buffalo Grove', state: 'Illinois' },
  { city: 'Buford', state: 'Georgia' }, { city: 'Burbank', state: 'California' },
  { city: 'Burbank', state: 'Illinois' }, { city: 'Burien', state: 'Washington' },
  { city: 'Burke', state: 'Virginia' }, { city: 'Burleson', state: 'Texas' },
  { city: 'Burlingame', state: 'California' }, { city: 'Burlington', state: 'Kentucky' },
  { city: 'Burlington', state: 'Iowa' }, { city: 'Burlington', state: 'North Carolina' },
  { city: 'Burlington', state: 'Massachusetts' }, { city: 'Burlington', state: 'New Jersey' },
  { city: 'Burlington', state: 'Vermont' }, { city: 'Burlington', state: 'Washington' },
  { city: 'Burlington', state: 'Wisconsin' }, { city: 'Burnsville', state: 'Minnesota' },
  { city: 'Burton', state: 'Michigan' }, { city: 'Butler', state: 'Pennsylvania' },
  { city: 'Cabot', state: 'Arkansas' }, { city: 'Cadillac', state: 'Michigan' },
  { city: 'Calexico', state: 'California' }, { city: 'Calhoun', state: 'Georgia' },
  { city: 'Calimesa', state: 'California' }, { city: 'Camarillo', state: 'California' },
  { city: 'Camas', state: 'Washington' }, { city: 'Cambridge', state: 'Maryland' },
  { city: 'Cambridge', state: 'Massachusetts' }, { city: 'Cambridge', state: 'Ohio' },
  { city: 'Camden', state: 'South Carolina' }, { city: 'Camden', state: 'New Jersey' },
  { city: 'Camden', state: 'Arkansas' }, { city: 'Cameron', state: 'Missouri' },
  { city: 'Campbell', state: 'California' }, { city: 'Campbell', state: 'Ohio' },
  { city: 'Canby', state: 'Oregon' }, { city: 'Canfield', state: 'Ohio' },
  { city: 'Canon City', state: 'Colorado' }, { city: 'Canonsburg', state: 'Pennsylvania' },
  { city: 'Canton', state: 'Ohio' }, { city: 'Canton', state: 'Georgia' },
  { city: 'Canton', state: 'Illinois' }, { city: 'Canton', state: 'Mississippi' },
  { city: 'Canton', state: 'Massachusetts' }, { city: 'Canton', state: 'Michigan' },
  { city: 'Canyon', state: 'Texas' }, { city: 'Cape Canaveral', state: 'Florida' },
  { city: 'Cape Coral', state: 'Florida' }, { city: 'Cape Girardeau', state: 'Missouri' },
  { city: 'Capitola', state: 'California' }, { city: 'Carbondale', state: 'Illinois' },
  { city: 'Caribou', state: 'Maine' }, { city: 'Carlisle', state: 'Pennsylvania' },
  { city: 'Carlsbad', state: 'New Mexico' }, { city: 'Carlsbad', state: 'California' },
  { city: 'Carmel', state: 'Indiana' }, { city: 'Carmichael', state: 'California' },
  { city: 'Carnegie', state: 'Pennsylvania' }, { city: 'Carol Stream', state: 'Illinois' },
  { city: 'Carpentersville', state: 'Illinois' }, { city: 'Carpinteria', state: 'California' },
  { city: 'Carrboro', state: 'North Carolina' }, { city: 'Carroll', state: 'Iowa' },
  { city: 'Carrollton', state: 'Georgia' }, { city: 'Carrollton', state: 'Texas' },
  { city: 'Carson', state: 'California' }, { city: 'Carson City', state: 'Nevada' },
  { city: 'Carteret', state: 'New Jersey' }, { city: 'Cartersville', state: 'Georgia' },
  { city: 'Carthage', state: 'Missouri' }, { city: 'Cary', state: 'Illinois' },
  { city: 'Cary', state: 'North Carolina' }, { city: 'Casa Grande', state: 'Arizona' },
  { city: 'Casper', state: 'Wyoming' }, { city: 'Casselberry', state: 'Florida' },
  { city: 'Castle Rock', state: 'Colorado' }, { city: 'Castro Valley', state: 'California' },
  { city: 'Catalina Foothills', state: 'Arizona' }, { city: 'Catonsville', state: 'Maryland' },
  { city: 'Cedar City', state: 'Utah' }, { city: 'Cedar Falls', state: 'Iowa' },
  { city: 'Cedar Hill', state: 'Texas' }, { city: 'Cedar Park', state: 'Texas' },
  { city: 'Cedar Rapids', state: 'Iowa' }, { city: 'Cedarburg', state: 'Wisconsin' },
  { city: 'Celina', state: 'Ohio' }, { city: 'Centerville', state: 'Ohio' },
  { city: 'Centerville', state: 'Utah' }, { city: 'Central Falls', state: 'Rhode Island' },
  { city: 'Centralia', state: 'Washington' }, { city: 'Centralia', state: 'Illinois' },
  { city: 'Centreville', state: 'Virginia' }, { city: 'Ceres', state: 'California' },
  { city: 'Cerritos', state: 'California' }, { city: 'Chalmette', state: 'Louisiana' },
  { city: 'Chambersburg', state: 'Pennsylvania' }, { city: 'Chamblee', state: 'Georgia' },
  { city: 'Champaign', state: 'Illinois' }, { city: 'Champlin', state: 'Minnesota' },
  { city: 'Chandler', state: 'Arizona' }, { city: 'Chanhassen', state: 'Minnesota' },
  { city: 'Channelview', state: 'Texas' }, { city: 'Chantilly', state: 'Virginia' },
  { city: 'Chanute', state: 'Kansas' }, { city: 'Chapel Hill', state: 'North Carolina' },
  { city: 'Charleston', state: 'Illinois' }, { city: 'Charleston', state: 'West Virginia' },
  { city: 'Charleston', state: 'South Carolina' }, { city: 'Charlotte', state: 'North Carolina' },
  { city: 'Charlotte', state: 'Michigan' }, { city: 'Charlottesville', state: 'Virginia' },
  { city: 'Chaska', state: 'Minnesota' }, { city: 'Chattanooga', state: 'Tennessee' },
  { city: 'Cheektowaga', state: 'New York' }, { city: 'Chehalis', state: 'Washington' },
  { city: 'Chelmsford', state: 'Massachusetts' }, { city: 'Chelsea', state: 'Massachusetts' },
  { city: 'Cheney', state: 'Washington' }, { city: 'Chesapeake', state: 'Virginia' },
  { city: 'Cheshire', state: 'Connecticut' }, { city: 'Chester', state: 'Virginia' },
  { city: 'Chester', state: 'South Carolina' }, { city: 'Chester', state: 'Pennsylvania' },
  { city: 'Chesterfield', state: 'Missouri' }, { city: 'Chesterton', state: 'Indiana' },
  { city: 'Cheverly', state: 'Maryland' }, { city: 'Chevy Chase', state: 'Maryland' },
  { city: 'Cheyenne', state: 'Wyoming' }, { city: 'Chicago', state: 'Illinois' },
  { city: 'Chicago Heights', state: 'Illinois' }, { city: 'Chickasha', state: 'Oklahoma' },
  { city: 'Chico', state: 'California' }, { city: 'Chicopee', state: 'Massachusetts' },
  { city: 'Chillicothe', state: 'Missouri' }, { city: 'Chillicothe', state: 'Ohio' },
  { city: 'Chino', state: 'California' }, { city: 'Chino Hills', state: 'California' },
  { city: 'Chino Valley', state: 'Arizona' }, { city: 'Chippewa Falls', state: 'Wisconsin' },
  { city: 'Choctaw', state: 'Oklahoma' }, { city: 'Christiansburg', state: 'Virginia' },
  { city: 'Chubbuck', state: 'Idaho' }, { city: 'Chula Vista', state: 'California' },
  { city: 'Cicero', state: 'Illinois' }, { city: 'Cincinnati', state: 'Ohio' },
  { city: 'Circleville', state: 'Ohio' }, { city: 'Citrus Heights', state: 'California' },
  { city: 'Claremont', state: 'California' }, { city: 'Claremont', state: 'New Hampshire' },
  { city: 'Claremore', state: 'Oklahoma' }, { city: 'Clarksburg', state: 'West Virginia' },
  { city: 'Clarksdale', state: 'Mississippi' }, { city: 'Clarkston', state: 'Georgia' },
  { city: 'Clarksville', state: 'Indiana' }, { city: 'Clarksville', state: 'Arkansas' },
  { city: 'Clarksville', state: 'Tennessee' }, { city: 'Clayton', state: 'California' },
  { city: 'Clayton', state: 'Missouri' }, { city: 'Clayton', state: 'North Carolina' },
  { city: 'Clearfield', state: 'Utah' }, { city: 'Clearlake', state: 'California' },
  { city: 'Clearwater', state: 'Florida' }, { city: 'Cleburne', state: 'Texas' },
  { city: 'Clemson', state: 'South Carolina' }, { city: 'Clermont', state: 'Florida' },
  { city: 'Cleveland', state: 'Mississippi' }, { city: 'Cleveland', state: 'Tennessee' },
  { city: 'Cleveland', state: 'Texas' }, { city: 'Cleveland', state: 'Ohio' },
  { city: 'Cleveland Heights', state: 'Ohio' }, { city: 'Clifton', state: 'New Jersey' },
  { city: 'Clifton', state: 'Colorado' }, { city: 'Clifton Park', state: 'New York' },
  { city: 'Clinton', state: 'Mississippi' }, { city: 'Clinton', state: 'Missouri' },
  { city: 'Clinton', state: 'Iowa' }, { city: 'Clinton', state: 'Maryland' },
  { city: 'Clinton', state: 'Massachusetts' }, { city: 'Clinton', state: 'Connecticut' },
  { city: 'Clinton', state: 'Illinois' }, { city: 'Clinton', state: 'Oklahoma' },
  { city: 'Clinton', state: 'North Carolina' }, { city: 'Clinton', state: 'Tennessee' },
  { city: 'Clinton', state: 'South Carolina' }, { city: 'Clinton', state: 'Utah' },
  { city: 'Clive', state: 'Iowa' }, { city: 'Cloquet', state: 'Minnesota' },
  { city: 'Cloverdale', state: 'California' },
];

const US_STATE_ABBRS = Object.values(STATE_ABBR).filter((v, i, arr) => arr.indexOf(v) === i).sort();



// ---------------------------------------------------------------------------
// COMBOBOX — shared search-or-pick control (drivers, parent loads, cities)
// ---------------------------------------------------------------------------

function Combobox({ options, value, onSelect, placeholder, emptyMessage, extraOption }) {
  const selected = options.find((o) => o.value === value);
  const [query, setQuery] = useState(selected ? selected.display : '');
  const [open, setOpen] = useState(false);

  const q = query.trim().toLowerCase();
  const filtered = (q ? options.filter((o) => o.searchText.includes(q)) : options).slice(0, 8);
  const rows = extraOption ? [...filtered, extraOption] : filtered;

  const handleSelect = (opt) => {
    onSelect(opt.value);
    setQuery(opt.display);
    setOpen(false);
  };

  const handleBlur = () => {
    setTimeout(() => {
      setOpen(false);
      const match = options.find((o) => o.value === value);
      setQuery(match ? match.display : '');
    }, 120);
  };

  return (
    <div className="combobox">
      <input
        value={query}
        placeholder={placeholder}
        onFocus={() => setOpen(true)}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onBlur={handleBlur}
      />
      {open && (
        <div className="combobox-list">
          {filtered.length === 0 && !extraOption && <div className="combobox-empty">{emptyMessage || 'No matches'}</div>}
          {rows.map((o) => (
            <div
              key={o.value}
              className={`combobox-option ${o.isAction ? 'combobox-option--action' : ''}`}
              onMouseDown={(e) => { e.preventDefault(); handleSelect(o); }}
            >
              {o.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CityField({ value, onChange, placeholder, customCities, onAddCustomCity }) {
  const [adding, setAdding] = useState(false);
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newZip, setNewZip] = useState('');
  const [addError, setAddError] = useState('');

  const hubOptions = usCities.map((c) => ({
    value: `${c.city}, ${c.state}`,
    label: `${c.city}, ${c.state} — ${c.zip}`,
    display: `${c.city}, ${c.state}`,
    searchText: `${c.city} ${c.state} ${c.zip}`.toLowerCase(),
    key: `${c.city}, ${c.state}`,
  }));
  const hubKeys = new Set(hubOptions.map((o) => o.key));

  const extraOptions = usCitiesExtra
    .map((c) => {
      const abbr = STATE_ABBR[c.state] || c.state;
      return {
        value: `${c.city}, ${abbr}`, label: `${c.city}, ${abbr}`, display: `${c.city}, ${abbr}`,
        searchText: `${c.city} ${abbr} ${c.state}`.toLowerCase(), key: `${c.city}, ${abbr}`,
      };
    })
    .filter((o) => !hubKeys.has(o.key));

  const customOptions = (customCities || []).map((c) => ({
    value: `${c.city}, ${c.state}`,
    label: `${c.city}, ${c.state} — ${c.zip}`,
    display: `${c.city}, ${c.state}`,
    searchText: `${c.city} ${c.state} ${c.zip}`.toLowerCase(),
    key: `${c.city}, ${c.state}`,
  }));

  const options = [...customOptions, ...hubOptions, ...extraOptions];

  const handleSelect = (val) => {
    if (val === '__add__') {
      setNewCity(''); setNewState(''); setNewZip(''); setAddError('');
      setAdding(true);
      return;
    }
    onChange(val);
  };

  const saveNewCity = async () => {
    if (!newCity.trim() || !newState) {
      setAddError('City and state are required.');
      return;
    }
    if (!/^\d{5}$/.test(newZip.trim())) {
      setAddError('ZIP must be 5 digits.');
      return;
    }
    const entry = { city: newCity.trim(), state: newState, zip: newZip.trim() };
    try {
      await onAddCustomCity(entry);
      onChange(`${entry.city}, ${entry.state}`);
      setAdding(false);
    } catch (e) {
      setAddError(e.message || 'Could not save city.');
    }
  };

  if (adding) {
    return (
      <div className="city-add-form">
        <input placeholder="City" value={newCity} onChange={(e) => setNewCity(e.target.value)} />
        <select value={newState} onChange={(e) => setNewState(e.target.value)}>
          <option value="">State…</option>
          {US_STATE_ABBRS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <input placeholder="ZIP" value={newZip} onChange={(e) => setNewZip(e.target.value)} maxLength={5} />
        {addError && <span className="field-error">{addError}</span>}
        <div className="city-add-actions">
          <button type="button" className="btn-ghost-sm" onClick={() => setAdding(false)}>Cancel</button>
          <button type="button" className="btn-primary-sm" onClick={saveNewCity}>Add city</button>
        </div>
      </div>
    );
  }

  return (
    <Combobox
      options={options}
      value={value}
      onSelect={handleSelect}
      placeholder={placeholder}
      emptyMessage="No matching US city or ZIP"
      extraOption={{ value: '__add__', label: '+ Add a new city…', display: '', isAction: true }}
    />
  );
}

const emptyLoadForm = {
  loadNumber: '', isPartial: false, parentLoadNumber: '', driverId: '',
  from: '', to: '', status: 'available', pickupDate: '', deliveryDate: '', total: '',
};

function LoadModal({ initial, drivers, loads, customCities, onAddCustomCity, onCancel, onSave }) {
  const [form, setForm] = useState(initial || emptyLoadForm);
  const [error, setError] = useState('');

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const fullLoadOptions = loads.filter((l) => !l.isPartial && l.id !== (initial && initial.id));

  const canSave = form.loadNumber.trim() && form.driverId && form.total !== '' &&
    (!form.isPartial || form.parentLoadNumber);

  const handleSave = () => {
    const trimmedNumber = form.loadNumber.trim();
    const duplicate = loads.some(
      (l) => l.id !== (initial && initial.id) && l.loadNumber.toLowerCase() === trimmedNumber.toLowerCase()
    );
    if (duplicate) {
      setError('This load number already exists.');
      return;
    }
    onSave({
      ...form,
      loadNumber: trimmedNumber,
      total: parseFloat(form.total) || 0,
      parentLoadNumber: form.isPartial ? form.parentLoadNumber : '',
    });
  };

  return (
    <div className="modal-overlay">
      <div className="modal modal--wide" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>{initial ? 'Edit Load' : 'Add Load'}</h3>
          <button className="icon-btn" onClick={onCancel}><X size={16} /></button>
        </div>

        <div className="modal-body">
          <div className="field-row">
            <label>Load #</label>
            <input
              value={form.loadNumber}
              onChange={(e) => { setError(''); setForm({ ...form, loadNumber: e.target.value }); }}
              placeholder="L-1001"
            />
            {error && <span className="field-error">{error}</span>}
          </div>

          <Toggle
            checked={form.isPartial}
            onChange={(val) => setForm({
              ...form,
              isPartial: val,
              parentLoadNumber: val ? form.parentLoadNumber : '',
              driverId: val ? '' : form.driverId,
            })}
            label="Partial load"
          />

          {form.isPartial && (
            <div className="field-row">
              <label>Parent Load #</label>
              <Combobox
                options={fullLoadOptions.map((l) => ({
                  value: l.loadNumber, label: l.loadNumber, display: l.loadNumber,
                  searchText: l.loadNumber.toLowerCase(),
                }))}
                value={form.parentLoadNumber}
                onSelect={(val) => {
                  const parent = fullLoadOptions.find((l) => l.loadNumber === val);
                  setForm({ ...form, parentLoadNumber: val, driverId: parent ? parent.driverId : form.driverId });
                }}
                placeholder="Search or pick load #…"
                emptyMessage="No full loads yet — add a full load first"
              />
              <span className="field-hint">Truck # is inherited from the parent load — a partial can't ride a different truck.</span>
            </div>
          )}

          {form.isPartial ? (
            <div className="field-row">
              <label>Truck #</label>
              <div className="truck-readonly">
                {form.driverId
                  ? (() => {
                      const d = drivers.find((x) => x.id === form.driverId);
                      return d ? `${d.truckNumber || '—'} — ${d.firstName} ${d.lastName}` : '—';
                    })()
                  : 'Select a parent load first'}
              </div>
            </div>
          ) : (
            <div className="field-row">
              <label>Truck #</label>
              <Combobox
                options={drivers.map((d) => ({
                  value: d.id,
                  label: `${d.truckNumber || '—'} — ${d.firstName} ${d.lastName}`,
                  display: `${d.truckNumber || '—'} — ${d.firstName} ${d.lastName}`,
                  searchText: `${d.truckNumber} ${d.firstName} ${d.lastName}`.toLowerCase(),
                }))}
                value={form.driverId}
                onSelect={(val) => setForm({ ...form, driverId: val })}
                placeholder="Search truck # or driver name…"
                emptyMessage="No drivers yet — add a driver first"
              />
            </div>
          )}

          <div className="field-row">
            <label>From</label>
            <CityField
              value={form.from}
              onChange={(val) => setForm({ ...form, from: val })}
              placeholder="City or ZIP…"
              customCities={customCities}
              onAddCustomCity={onAddCustomCity}
            />
          </div>
          <div className="field-row">
            <label>To</label>
            <CityField
              value={form.to}
              onChange={(val) => setForm({ ...form, to: val })}
              placeholder="City or ZIP…"
              customCities={customCities}
              onAddCustomCity={onAddCustomCity}
            />
          </div>

          <div className="field-row">
            <label>Pickup Date</label>
            <input type="date" value={form.pickupDate} onChange={update('pickupDate')} />
          </div>
          <div className="field-row">
            <label>Delivery Date</label>
            <input type="date" value={form.deliveryDate} onChange={update('deliveryDate')} />
          </div>

          <div className="field-row">
            <label>Total</label>
            <input type="number" min="0" step="0.01" value={form.total} onChange={update('total')} placeholder="2500" />
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onCancel}>Cancel</button>
          <button className="btn-primary" disabled={!canSave} onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
}

function Loads({ loads, setLoads, drivers, customCities, setCustomCities, logActivity, accessToken }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [driverFilter, setDriverFilter] = useState('all');
  const [sortField, setSortField] = useState(null);
  const [sortDir, setSortDir] = useState('asc');
  const [selectedIds, setSelectedIds] = useState(() => new Set());
  const [page, setPage] = useState(1);
  const [saveError, setSaveError] = useState('');
  const PAGE_SIZE = 25;

  const editingLoad = loads.find((l) => l.id === editingId) || null;
  const table = sbTable('loads', accessToken);

  const openAdd = () => { setEditingId(null); setModalOpen(true); setSaveError(''); };
  const openEdit = (id) => { setEditingId(id); setModalOpen(true); setConfirmDeleteId(null); setSaveError(''); };
  const closeModal = () => setModalOpen(false);

  const saveLoad = async (form) => {
    const row = loadToDb(form);
    try {
      if (editingId) {
        const [updated] = await table.update(editingId, row);
        setLoads(loads.map((l) => (l.id === editingId ? loadFromDb(updated) : l)));
        logActivity(`Edited load ${form.loadNumber}`);
      } else {
        const [created] = await table.insert(row);
        setLoads([...loads, loadFromDb(created)]);
        logActivity(`Added ${form.isPartial ? 'partial' : 'full'} load ${form.loadNumber}`);
      }
      setModalOpen(false);
    } catch (e) {
      const msg = (e.message || '').toLowerCase().includes('duplicate')
        ? 'This load number already exists.'
        : (e.message || 'Could not save load.');
      setSaveError(msg);
    }
  };

  const deleteLoad = async (id) => {
    const l = loads.find((x) => x.id === id);
    try {
      await table.remove(id);
      setLoads(loads.filter((x) => x.id !== id));
      if (l) logActivity(`Deleted load ${l.loadNumber}`);
    } catch (e) {
      setSaveError(e.message || 'Could not delete load.');
    }
    setConfirmDeleteId(null);
  };

  const addCustomCity = async (entry) => {
    const [created] = await sbTable('custom_cities', accessToken).insert(entry);
    const mapped = { city: created.city, state: created.state, zip: created.zip };
    setCustomCities([...customCities, mapped]);
    return mapped;
  };

  const driverById = useMemo(() => {
    const map = {};
    drivers.forEach((d) => { map[d.id] = d; });
    return map;
  }, [drivers]);

  const todayIso = isoDate(new Date());
  const isOverdue = (l) => l.deliveryDate && l.deliveryDate < todayIso && l.status !== 'delivered';
  const overdueCount = useMemo(() => loads.filter(isOverdue).length, [loads]);

  const resetToPage1 = () => setPage(1);

  const filteredLoads = loads.filter((l) => {
    const matchesSearch = l.loadNumber.toLowerCase().includes(search.trim().toLowerCase());
    const matchesStatus = statusFilter === 'all' || l.status === statusFilter;
    const matchesDriver = driverFilter === 'all' || l.driverId === driverFilter;
    return matchesSearch && matchesStatus && matchesDriver;
  });

  const sortedLoads = useMemo(() => {
    if (!sortField) return filteredLoads;
    const arr = [...filteredLoads];
    arr.sort((a, b) => {
      let av, bv;
      switch (sortField) {
        case 'truckNumber':
          av = (driverById[a.driverId]?.truckNumber || '').toLowerCase();
          bv = (driverById[b.driverId]?.truckNumber || '').toLowerCase();
          break;
        case 'from': av = (a.from || '').toLowerCase(); bv = (b.from || '').toLowerCase(); break;
        case 'to': av = (a.to || '').toLowerCase(); bv = (b.to || '').toLowerCase(); break;
        case 'status': av = a.status; bv = b.status; break;
        case 'pickupDate': av = a.pickupDate || ''; bv = b.pickupDate || ''; break;
        case 'deliveryDate': av = a.deliveryDate || ''; bv = b.deliveryDate || ''; break;
        case 'total': av = a.total; bv = b.total; break;
        default: av = a.loadNumber.toLowerCase(); bv = b.loadNumber.toLowerCase();
      }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return arr;
  }, [filteredLoads, sortField, sortDir, driverById]);

  const totalPages = Math.max(1, Math.ceil(sortedLoads.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageLoads = sortedLoads.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };
  const SortArrow = ({ field }) => sortField === field ? <span className="sort-arrow">{sortDir === 'asc' ? '↑' : '↓'}</span> : null;

  const toggleSelect = (id) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelectedIds(next);
  };
  const allPageSelected = pageLoads.length > 0 && pageLoads.every((l) => selectedIds.has(l.id));
  const toggleSelectAllPage = () => {
    const next = new Set(selectedIds);
    if (allPageSelected) pageLoads.forEach((l) => next.delete(l.id));
    else pageLoads.forEach((l) => next.add(l.id));
    setSelectedIds(next);
  };

  const markSelectedDelivered = async () => {
    const ids = Array.from(selectedIds);
    try {
      await sbRequest(`/rest/v1/loads?id=in.(${ids.join(',')})`, {
        method: 'PATCH', body: { status: 'delivered' }, accessToken, prefer: 'return=minimal',
      });
      setLoads(loads.map((l) => (selectedIds.has(l.id) ? { ...l, status: 'delivered' } : l)));
      logActivity(`Marked ${selectedIds.size} load(s) as Delivered`);
      setSelectedIds(new Set());
    } catch (e) {
      setSaveError(e.message || 'Could not update selected loads.');
    }
  };

  const exportExcel = () => {
    const header = ['Load #', 'Partial', 'Parent Load #', 'Truck #', 'Driver', 'From', 'To', 'Status', 'Pickup', 'Delivery', 'Total'];
    const rows = sortedLoads.map((l) => {
      const d = driverById[l.driverId];
      return [
        l.loadNumber, l.isPartial ? 'Yes' : 'No', l.parentLoadNumber || '',
        d?.truckNumber || '', d ? `${d.firstName} ${d.lastName}` : '',
        l.from || '', l.to || '', statusLabel(l.status),
        fmtDateInput(l.pickupDate), fmtDateInput(l.deliveryDate), l.total,
      ];
    });
    const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
    ws['!cols'] = header.map(() => ({ wch: 14 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Loads');
    XLSX.writeFile(wb, `loads-${todayIso}.xlsx`);
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Loads</h1>
          <p className="subtitle">All booked loads</p>
        </div>
        <div className="loads-header-actions">
          <button className="btn-ghost" onClick={exportExcel}><Download size={14} /> Excel</button>
          <button className="btn-primary" onClick={openAdd}><Plus size={15} /> Add Load</button>
        </div>
      </header>

      {overdueCount > 0 && (
        <div className="overdue-banner">
          <AlertTriangle size={14} /> {overdueCount} load{overdueCount > 1 ? 's are' : ' is'} overdue — delivery date has passed and status isn't Delivered yet.
        </div>
      )}

      {saveError && (
        <div className="overdue-banner"><AlertTriangle size={14} /> {saveError}</div>
      )}

      <div className="loads-toolbar">
        <div className="search-box">
          <Search size={14} className="search-icon" />
          <input
            placeholder="Search by load #"
            value={search}
            onChange={(e) => { setSearch(e.target.value); resetToPage1(); }}
          />
        </div>
        <select className="period-select" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); resetToPage1(); }}>
          <option value="all">All statuses</option>
          {statusOptions.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
        </select>
        <select className="period-select" value={driverFilter} onChange={(e) => { setDriverFilter(e.target.value); resetToPage1(); }}>
          <option value="all">All drivers</option>
          {drivers.map((d) => <option key={d.id} value={d.id}>{d.firstName} {d.lastName}</option>)}
        </select>
      </div>

      {selectedIds.size > 0 && (
        <div className="bulk-bar">
          <span>{selectedIds.size} selected</span>
          <button className="btn-primary-sm" onClick={markSelectedDelivered}>Mark as Delivered</button>
          <button className="btn-ghost-sm" onClick={() => setSelectedIds(new Set())}>Clear selection</button>
        </div>
      )}

      {sortedLoads.length === 0 ? (
        <div className="empty-state">
          {loads.length === 0 ? 'No loads yet. Add your first load to get started.' : 'No loads match your search or filter.'}
        </div>
      ) : (
        <>
          <div className="loads-table">
            <div className="loads-row loads-row--head">
              <span><input type="checkbox" checked={allPageSelected} onChange={toggleSelectAllPage} /></span>
              <span>N</span>
              <button className="loads-sort-btn" onClick={() => toggleSort('loadNumber')}>Load # <SortArrow field="loadNumber" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('truckNumber')}>Truck # <SortArrow field="truckNumber" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('from')}>From <SortArrow field="from" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('to')}>To <SortArrow field="to" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('status')}>Status <SortArrow field="status" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('pickupDate')}>Pickup <SortArrow field="pickupDate" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('deliveryDate')}>Delivery <SortArrow field="deliveryDate" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('total')}>Total <SortArrow field="total" /></button>
              <span></span>
            </div>

            {pageLoads.map((l, i) => (
              <div className={`loads-row ${isOverdue(l) ? 'loads-row--overdue' : ''}`} key={l.id}>
                <span><input type="checkbox" checked={selectedIds.has(l.id)} onChange={() => toggleSelect(l.id)} /></span>
                <span className="loads-n">{(safePage - 1) * PAGE_SIZE + i + 1}</span>
                <span className="loads-number-cell">
                  {l.loadNumber}
                  {l.isPartial && (
                    <span className="parent-hint">
                      <CornerDownRight size={11} /> {l.parentLoadNumber || '—'}
                    </span>
                  )}
                </span>
                <span>{driverById[l.driverId]?.truckNumber || '—'}</span>
                <span className="loads-ellipsis">{l.from || '—'}</span>
                <span className="loads-ellipsis">{l.to || '—'}</span>
                <select
                  className={`status-inline-select status-inline-select--${l.status}`}
                  value={l.status}
                  onChange={async (e) => {
                    const newStatus = e.target.value;
                    try {
                      await table.update(l.id, { status: newStatus });
                      setLoads(loads.map((x) => (x.id === l.id ? { ...x, status: newStatus } : x)));
                      logActivity(`Marked load ${l.loadNumber} as ${statusLabel(newStatus)}`);
                    } catch (err) {
                      setSaveError(err.message || 'Could not update status.');
                    }
                  }}
                >
                  {statusOptions.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
                </select>
                <span>{fmtDateInput(l.pickupDate)}</span>
                <span>{fmtDateInput(l.deliveryDate)}</span>
                <span>{currency(l.total)}</span>

                {confirmDeleteId === l.id ? (
                  <div className="confirm-row confirm-row--table">
                    <button className="btn-ghost-sm" onClick={() => setConfirmDeleteId(null)}>Cancel</button>
                    <button className="btn-danger-sm" onClick={() => deleteLoad(l.id)}>Delete</button>
                  </div>
                ) : (
                  <div className="driver-plain-actions">
                    <button className="icon-btn" onClick={() => openEdit(l.id)}><Pencil size={13} /></button>
                    <button className="icon-btn" onClick={() => setConfirmDeleteId(l.id)}><Trash2 size={13} /></button>
                  </div>
                )}
              </div>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="pagination-row">
              <button className="icon-btn" disabled={safePage === 1} onClick={() => setPage(safePage - 1)}><ChevronLeft size={16} /></button>
              <span className="pagination-label">Page {safePage} of {totalPages} · {sortedLoads.length} loads</span>
              <button className="icon-btn" disabled={safePage === totalPages} onClick={() => setPage(safePage + 1)}><ChevronRight size={16} /></button>
            </div>
          )}
        </>
      )}

      {modalOpen && (
        <LoadModal
          initial={editingLoad}
          drivers={drivers}
          loads={loads}
          customCities={customCities}
          onAddCustomCity={addCustomCity}
          onCancel={closeModal}
          onSave={saveLoad}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// SALARY PAGE
// ---------------------------------------------------------------------------

function DayDetailModal({ driver, dayLabel, dayLoads, onClose }) {
  const total = dayLoads.reduce((sum, l) => sum + l.total, 0);

  return (
    <div className="modal-overlay">
      <div className="modal modal--wide" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>{driver.firstName} {driver.lastName} — {dayLabel}</h3>
          <button className="icon-btn" onClick={onClose}><X size={16} /></button>
        </div>

        {dayLoads.length === 0 ? (
          <div className="empty-state">No loads for this day.</div>
        ) : (
          <div className="salary-detail-list">
            {dayLoads.map((l) => (
              <div className="salary-detail-row" key={l.id}>
                <div className="salary-detail-main">
                  <span className="salary-detail-load">{l.loadNumber}</span>
                  <span className="salary-detail-route">{l.from || '—'} → {l.to || '—'}</span>
                </div>
                <div className="salary-detail-nums">
                  <span>{l.isPartial ? 'Partial' : 'Full'}</span>
                  <span className="salary-detail-net">{currency(l.total)}</span>
                </div>
              </div>
            ))}
            <div className="salary-detail-total">
              <span>Total for the day</span>
              <span>{currency(total)}</span>
            </div>
          </div>
        )}

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}

function Salary({ loads, drivers }) {
  const [weekAnchor, setWeekAnchor] = useState(new Date());
  const [detail, setDetail] = useState(null);
  const [sortField, setSortField] = useState(null);
  const [sortDir, setSortDir] = useState('asc');

  const weekStart = startOfWeek(weekAnchor);
  const days = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(weekStart);
      d.setDate(weekStart.getDate() + i);
      return {
        iso: isoDate(d),
        weekday: d.toLocaleDateString('en-US', { weekday: 'short' }),
        sub: d.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' }),
      };
    });
  }, [weekStart.getTime()]);

  const cellData = useMemo(() => {
    const map = {};
    loads.forEach((l) => {
      const key = `${l.driverId}|${l.pickupDate}`;
      if (!map[key]) map[key] = [];
      map[key].push(l);
    });
    return map;
  }, [loads]);

  const rangeLabel = `${days[0]?.weekday} ${days[0]?.sub} – ${days[6]?.weekday} ${days[6]?.sub}`;

  const shiftWeek = (delta) => {
    const d = new Date(weekAnchor);
    d.setDate(d.getDate() + delta * 7);
    setWeekAnchor(d);
  };

  const detailDriver = detail ? drivers.find((d) => d.id === detail.driverId) : null;
  const detailLoads = detail ? (cellData[`${detail.driverId}|${detail.iso}`] || []) : [];
  const detailDayLabel = detail ? `${detail.weekday} ${detail.sub}` : '';

  const driverRows = useMemo(() => {
    const rows = drivers.map((driver) => {
      const rowTotal = days.reduce((sum, d) => {
        const cell = cellData[`${driver.id}|${d.iso}`] || [];
        return sum + cell.reduce((s, l) => s + l.total, 0);
      }, 0);
      return { driver, rowTotal };
    });
    if (sortField) {
      rows.sort((a, b) => {
        let av, bv;
        if (sortField === 'name') {
          av = `${a.driver.firstName} ${a.driver.lastName}`.toLowerCase();
          bv = `${b.driver.firstName} ${b.driver.lastName}`.toLowerCase();
        } else {
          av = a.rowTotal; bv = b.rowTotal;
        }
        if (av < bv) return sortDir === 'asc' ? -1 : 1;
        if (av > bv) return sortDir === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return rows;
  }, [drivers, days, cellData, sortField, sortDir]);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };
  const SortArrow = ({ field }) => sortField === field ? <span className="sort-arrow">{sortDir === 'asc' ? '↑' : '↓'}</span> : null;

  const exportExcel = () => {
    const header = ['Truck #', 'Driver', 'Weekly total', ...days.map((d) => `${d.weekday} ${d.sub}`)];
    const rows = drivers.map((driver) => {
      const dayValues = days.map((d) => {
        const cell = cellData[`${driver.id}|${d.iso}`] || [];
        return cell.reduce((s, l) => s + l.total, 0);
      });
      const rowTotal = dayValues.reduce((s, v) => s + v, 0);
      return [driver.truckNumber || '—', `${driver.firstName} ${driver.lastName}`, rowTotal, ...dayValues];
    });
    const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
    ws['!cols'] = [{ wch: 10 }, { wch: 22 }, { wch: 14 }, ...days.map(() => ({ wch: 12 }))];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Salary');
    XLSX.writeFile(wb, `salary-${days[0]?.iso}-to-${days[6]?.iso}.xlsx`);
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Salary</h1>
          <p className="subtitle">Weekly driver earnings, based on booked loads</p>
        </div>
        <div className="week-nav">
          <button className="icon-btn" onClick={() => shiftWeek(-1)}><ChevronLeft size={16} /></button>
          <span className="week-nav-label">{rangeLabel}</span>
          <button className="icon-btn" onClick={() => shiftWeek(1)}><ChevronRight size={16} /></button>
          <button className="btn-ghost salary-export-btn" onClick={exportExcel}>
            <Download size={14} /> Excel
          </button>
        </div>
      </header>

      {drivers.length === 0 ? (
        <div className="empty-state">No drivers yet. Add drivers to see their weekly earnings here.</div>
      ) : (
        <div className="salary-table-wrap">
          <div className="salary-table">
            <div className="salary-row salary-row--head">
              <span>Truck #</span>
              <button className="loads-sort-btn" onClick={() => toggleSort('name')}>Driver <SortArrow field="name" /></button>
              <button className="loads-sort-btn" onClick={() => toggleSort('total')}>Weekly total <SortArrow field="total" /></button>
              {days.map((d) => (
                <span key={d.iso}>{d.weekday} <span className="salary-head-sub">{d.sub}</span></span>
              ))}
            </div>

            {driverRows.map(({ driver, rowTotal }) => {
              return (
                <div className="salary-row" key={driver.id}>
                  <span className="salary-truck">{driver.truckNumber || '—'}</span>
                  <span className="salary-driver-name">{driver.firstName} {driver.lastName}</span>
                  <span className="salary-total">{currency(rowTotal)}</span>
                  {days.map((d) => {
                    const cell = cellData[`${driver.id}|${d.iso}`] || [];
                    const dayTotal = cell.reduce((s, l) => s + l.total, 0);
                    const hasLoads = cell.length > 0;
                    const isMulti = cell.length >= 2;
                    return (
                      <button
                        key={d.iso}
                        className={`salary-cell ${hasLoads ? (isMulti ? 'salary-cell--multi' : 'salary-cell--active') : ''}`}
                        onClick={() => setDetail({ driverId: driver.id, iso: d.iso, weekday: d.weekday, sub: d.sub })}
                      >
                        {hasLoads ? currency(dayTotal) : <span className="salary-cell-empty">No loads</span>}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {detail && (
        <DayDetailModal
          driver={detailDriver}
          dayLabel={detailDayLabel}
          dayLoads={detailLoads}
          onClose={() => setDetail(null)}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// CALENDAR PAGE
// ---------------------------------------------------------------------------

const WEEKDAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function buildMonthGrid(monthAnchor) {
  const first = startOfMonth(monthAnchor);
  const startOffset = (first.getDay() + 6) % 7; // Monday = 0
  const daysInMonth = endOfMonth(monthAnchor).getDate();
  const cells = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(monthAnchor.getFullYear(), monthAnchor.getMonth(), d);
    cells.push({ date, iso: isoDate(date) });
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

function DayNotesModal({ dateLabel, notes, onAdd, onDelete, onClose, error }) {
  const [text, setText] = useState('');

  const handleAdd = () => {
    if (!text.trim()) return;
    onAdd(text.trim());
    setText('');
  };

  return (
    <div className="modal-overlay">
      <div className="modal modal--wide" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>{dateLabel}</h3>
          <button className="icon-btn" onClick={onClose}><X size={16} /></button>
        </div>

        {error && <span className="field-error">{error}</span>}

        {notes.length === 0 ? (
          <div className="empty-state">No notes for this day yet.</div>
        ) : (
          <div className="notes-list">
            {notes.map((n) => (
              <div className="notes-row" key={n.id}>
                <span>{n.text}</span>
                <button className="icon-btn" onClick={() => onDelete(n.id)}><Trash2 size={13} /></button>
              </div>
            ))}
          </div>
        )}

        <div className="notes-add-row">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Add a note…"
            onKeyDown={(e) => { if (e.key === 'Enter') handleAdd(); }}
          />
          <button className="btn-primary-sm" onClick={handleAdd}>Add</button>
        </div>

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}

function Calendar({ calendarNotes, setCalendarNotes, logActivity, accessToken, userId }) {
  const [monthAnchor, setMonthAnchor] = useState(startOfMonth(new Date()));
  const [selectedIso, setSelectedIso] = useState(null);
  const [noteError, setNoteError] = useState('');

  const cells = useMemo(() => buildMonthGrid(monthAnchor), [monthAnchor.getTime()]);
  const monthLabel = monthAnchor.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const todayIso = isoDate(new Date());

  const shiftMonth = (delta) => {
    const d = new Date(monthAnchor);
    d.setMonth(d.getMonth() + delta);
    setMonthAnchor(startOfMonth(d));
  };

  const addNote = async (iso, text) => {
    setNoteError('');
    try {
      const [created] = await sbTable('calendar_notes', accessToken).insert({
        note_date: iso, note_text: text, created_by: userId || null,
      });
      const existing = calendarNotes[iso] || [];
      setCalendarNotes({ ...calendarNotes, [iso]: [...existing, { id: created.id, text: created.note_text }] });
      logActivity(`Added a calendar note on ${iso}`);
    } catch (e) {
      setNoteError(e.message || 'Could not save note.');
    }
  };
  const deleteNote = async (iso, id) => {
    setNoteError('');
    try {
      await sbTable('calendar_notes', accessToken).remove(id);
      const existing = calendarNotes[iso] || [];
      setCalendarNotes({ ...calendarNotes, [iso]: existing.filter((n) => n.id !== id) });
    } catch (e) {
      setNoteError(e.message || 'Could not delete note.');
    }
  };

  const selectedDate = selectedIso ? new Date(selectedIso) : null;
  const selectedLabel = selectedDate
    ? selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })
    : '';

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Calendar</h1>
          <p className="subtitle">Click a day to view or add notes</p>
        </div>
        <div className="week-nav">
          <button className="icon-btn" onClick={() => shiftMonth(-1)}><ChevronLeft size={16} /></button>
          <span className="week-nav-label">{monthLabel}</span>
          <button className="icon-btn" onClick={() => shiftMonth(1)}><ChevronRight size={16} /></button>
        </div>
      </header>

      <div className="cal-grid">
        {WEEKDAY_HEADERS.map((w) => <div className="cal-weekday" key={w}>{w}</div>)}
        {cells.map((cell, i) => {
          if (!cell) return <div className="cal-cell cal-cell--empty" key={`empty-${i}`} />;
          const notes = calendarNotes[cell.iso] || [];
          const isToday = cell.iso === todayIso;
          return (
            <button
              key={cell.iso}
              className={`cal-cell ${isToday ? 'cal-cell--today' : ''}`}
              onClick={() => setSelectedIso(cell.iso)}
            >
              <span className="cal-daynum">{cell.date.getDate()}</span>
              {notes.length > 0 && (
                <span className="cal-note-preview">
                  <span className="cal-note-dot" />
                  {notes.length === 1 ? notes[0].text : `${notes.length} notes`}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {selectedIso && (
        <DayNotesModal
          dateLabel={selectedLabel}
          notes={calendarNotes[selectedIso] || []}
          onAdd={(text) => addNote(selectedIso, text)}
          onDelete={(id) => deleteNote(selectedIso, id)}
          onClose={() => { setSelectedIso(null); setNoteError(''); }}
          error={noteError}
        />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// SETTINGS PAGE
// ---------------------------------------------------------------------------

function SettingsPage({ settings, setSettings, onSave, accessToken }) {
  const [draft, setDraft] = useState(settings);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  const update = (field) => (e) => { setDraft({ ...draft, [field]: e.target.value }); setSaved(false); };

  const handleAvatar = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { setDraft({ ...draft, avatarUrl: reader.result }); setSaved(false); };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    setError('');
    try {
      await sbTable('settings', accessToken).update(1, {
        full_pct: draft.fullPct,
        partial_pct: draft.partialPct,
        dispatcher_name: draft.dispatcherName,
        avatar_url: draft.avatarUrl,
        theme: draft.theme,
      });
      setSettings(draft);
      onSave && onSave();
      setSaved(true);
    } catch (e) {
      setError(e.message || 'Could not save settings.');
    }
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <h1>Settings</h1>
          <p className="subtitle">Company-wide values used across the app</p>
        </div>
      </header>

      <div className="settings-list">
        <div className="field-row">
          <label>% for Full Loads</label>
          <input
            type="number" min="0" max="100" step="0.1"
            value={draft.fullPct}
            onChange={(e) => { setDraft({ ...draft, fullPct: parseFloat(e.target.value) || 0 }); setSaved(false); }}
          />
        </div>
        <div className="field-row">
          <label>% for Partial Loads</label>
          <input
            type="number" min="0" max="100" step="0.1"
            value={draft.partialPct}
            onChange={(e) => { setDraft({ ...draft, partialPct: parseFloat(e.target.value) || 0 }); setSaved(false); }}
          />
        </div>
        <div className="field-row">
          <label>Dispatcher Name to Show on Pages</label>
          <input type="text" value={draft.dispatcherName} onChange={update('dispatcherName')} />
        </div>

        <div className="field-row">
          <label>Profile Picture</label>
          <div className="avatar-upload-row">
            {draft.avatarUrl
              ? <img src={draft.avatarUrl} alt="" className="avatar-preview" />
              : <div className="avatar-preview avatar-preview--empty">
                  {(draft.dispatcherName || '').split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase()}
                </div>}
            <label className="btn-ghost avatar-upload-btn">
              Upload image
              <input type="file" accept="image/*" onChange={handleAvatar} style={{ display: 'none' }} />
            </label>
            {draft.avatarUrl && (
              <button className="btn-ghost" onClick={() => { setDraft({ ...draft, avatarUrl: '' }); setSaved(false); }}>Remove</button>
            )}
          </div>
        </div>

        <div className="field-row">
          <label>Theme</label>
          <div className="theme-toggle-row">
            <button
              className={`theme-option ${draft.theme !== 'light' ? 'theme-option--active' : ''}`}
              onClick={() => { setDraft({ ...draft, theme: 'dark' }); setSaved(false); }}
            >
              Dark
            </button>
            <button
              className={`theme-option ${draft.theme === 'light' ? 'theme-option--active' : ''}`}
              onClick={() => { setDraft({ ...draft, theme: 'light' }); setSaved(false); }}
            >
              Light
            </button>
          </div>
        </div>

        <div className="settings-save-row">
          <button className="btn-primary" onClick={handleSave}>Save changes</button>
          {saved && <span className="settings-saved-msg">Saved.</span>}
          {error && <span className="field-error">{error}</span>}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// NOTIFICATION BELL
// ---------------------------------------------------------------------------

function timeAgo(date) {
  const mins = Math.floor((Date.now() - date.getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function NotificationBell({ log }) {
  const [open, setOpen] = useState(false);
  const [lastSeen, setLastSeen] = useState(0);
  const unread = Math.max(0, log.length - lastSeen);

  const toggleOpen = () => {
    const next = !open;
    setOpen(next);
    if (next) setLastSeen(log.length);
  };

  return (
    <div className="bell-wrap" tabIndex={-1} onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false); }}>
      <button className="bell-btn" onClick={toggleOpen}>
        <Bell size={17} strokeWidth={2} />
        {unread > 0 && <span className="bell-badge">{unread > 9 ? '9+' : unread}</span>}
      </button>
      {open && (
        <div className="bell-panel">
          <div className="bell-panel-title">Recent activity</div>
          {log.length === 0 ? (
            <div className="bell-empty">No activity yet.</div>
          ) : (
            log.map((entry) => (
              <div className="bell-entry" key={entry.id}>
                <div className="bell-entry-text">{entry.text}</div>
                <div className="bell-entry-meta">{entry.user} · {timeAgo(entry.time)}</div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// AUTH SCREEN (Supabase email/password)
// ---------------------------------------------------------------------------

function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState('signin'); // 'signin' | 'signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setError(''); setInfo('');
    if (!email.trim() || !password) { setError('Enter email and password.'); return; }
    setLoading(true);
    try {
      if (mode === 'signup') {
        const data = await authSignUp(email.trim(), password);
        if (data && data.access_token) {
          onAuthenticated({ accessToken: data.access_token, refreshToken: data.refresh_token, email: data.user?.email || email.trim(), userId: data.user?.id });
        } else {
          setInfo('Account created. Check your email to confirm, then sign in.');
          setMode('signin');
        }
      } else {
        const data = await authSignIn(email.trim(), password);
        onAuthenticated({ accessToken: data.access_token, refreshToken: data.refresh_token, email: data.user?.email || email.trim(), userId: data.user?.id });
      }
    } catch (e) {
      setError(e.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-screen">
      <div className="auth-card">
        <div className="auth-brand"><Truck size={20} strokeWidth={2.2} /> SDS UZ INC</div>
        <h2>{mode === 'signin' ? 'Sign in' : 'Create an account'}</h2>

        <div className="field-row">
          <label>Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
        </div>
        <div className="field-row">
          <label>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
            onKeyDown={(e) => { if (e.key === 'Enter') handleSubmit(); }} />
        </div>

        {error && <span className="field-error">{error}</span>}
        {info && <span className="settings-saved-msg">{info}</span>}

        <button className="btn-primary auth-submit" disabled={loading} onClick={handleSubmit}>
          {loading ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Sign up'}
        </button>

        <button className="auth-switch" onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(''); setInfo(''); }}>
          {mode === 'signin' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// APP SHELL
// ---------------------------------------------------------------------------

export default function DispatchCRM() {
  const [active, setActive] = useState('dashboard');
  const [session, setSession] = useState(null);
  const [sessionChecked, setSessionChecked] = useState(false);
  const [loads, setLoads] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [customCities, setCustomCities] = useState([]);
  const [calendarNotes, setCalendarNotes] = useState({});
  const [activityLog, setActivityLog] = useState([]);
  const [settings, setSettings] = useState({
    fullPct: 2,
    partialPct: 3,
    dispatcherName: 'Morgan Reyes',
    avatarUrl: '',
    theme: 'dark',
  });

  useEffect(() => {
    try {
      const saved = localStorage.getItem('sds_session');
      if (saved) setSession(JSON.parse(saved));
    } catch (e) { /* no saved session yet */ }
    setSessionChecked(true);
  }, []);

  const handleAuthenticated = (sess) => {
    setSession(sess);
    try { localStorage.setItem('sds_session', JSON.stringify(sess)); } catch (e) { /* ignore */ }
  };

  const handleLogout = () => {
    setSession(null);
    try { localStorage.removeItem('sds_session'); } catch (e) { /* ignore */ }
  };

  // Keep a ref to the latest session so the refresh interval below always
  // refreshes with the current refresh_token, without re-triggering itself
  // every time session changes (Supabase rotates the refresh_token on use).
  const sessionRef = useRef(session);
  useEffect(() => { sessionRef.current = session; }, [session]);

  const refreshSession = async (sess) => {
    if (!sess || !sess.refreshToken) return null;
    try {
      const data = await authRefresh(sess.refreshToken);
      const next = { accessToken: data.access_token, refreshToken: data.refresh_token, email: sess.email, userId: sess.userId };
      setSession(next);
      try { localStorage.setItem('sds_session', JSON.stringify(next)); } catch (e) { /* ignore */ }
      return next;
    } catch (e) {
      // Refresh token itself is no longer valid — sign the user out cleanly.
      handleLogout();
      return null;
    }
  };

  // Refresh once immediately whenever a session becomes active (covers the
  // "left the tab closed for a while, token already expired" case), then
  // keep refreshing every 45 minutes so the 1-hour token never goes stale
  // during active use.
  useEffect(() => {
    if (!session) return;
    refreshSession(sessionRef.current);
    const interval = setInterval(() => {
      if (sessionRef.current) refreshSession(sessionRef.current);
    }, 45 * 60 * 1000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [!!session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('drivers', session.accessToken).list('select=*&order=created_at.asc');
        setDrivers(rows.map((r) => ({ id: r.id, firstName: r.first_name, lastName: r.last_name, truckNumber: r.truck_number, type: r.type })));
      } catch (e) {
        console.error('Failed to load drivers from Supabase', e);
      }
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('settings', session.accessToken).list('select=*&id=eq.1');
        const row = rows && rows[0];
        if (row) {
          setSettings({
            fullPct: row.full_pct,
            partialPct: row.partial_pct,
            dispatcherName: row.dispatcher_name,
            avatarUrl: row.avatar_url || '',
            theme: row.theme,
          });
        }
      } catch (e) {
        console.error('Failed to load settings from Supabase', e);
      }
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('loads', session.accessToken).list('select=*&order=created_at.asc');
        setLoads(rows.map(loadFromDb));
      } catch (e) {
        console.error('Failed to load loads from Supabase', e);
      }
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('calendar_notes', session.accessToken).list('select=*&order=created_at.asc');
        const grouped = {};
        rows.forEach((r) => {
          if (!grouped[r.note_date]) grouped[r.note_date] = [];
          grouped[r.note_date].push({ id: r.id, text: r.note_text });
        });
        setCalendarNotes(grouped);
      } catch (e) {
        console.error('Failed to load calendar notes from Supabase', e);
      }
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('custom_cities', session.accessToken).list('select=*&order=created_at.asc');
        setCustomCities(rows.map((r) => ({ city: r.city, state: r.state, zip: r.zip })));
      } catch (e) {
        console.error('Failed to load custom cities from Supabase', e);
      }
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    (async () => {
      try {
        const rows = await sbTable('activity_log', session.accessToken).list('select=*&order=created_at.desc&limit=50');
        setActivityLog(rows.map((r) => ({ id: r.id, text: r.action_text, user: r.user_email, time: new Date(r.created_at) })));
      } catch (e) {
        console.error('Failed to load activity log from Supabase', e);
      }
    })();
  }, [session]);

  const logActivity = (text) => {
    const user = session?.email || 'Admin';
    setActivityLog((prev) => [
      { id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, text, user, time: new Date() },
      ...prev,
    ].slice(0, 50));
    if (session) {
      sbTable('activity_log', session.accessToken)
        .insert({ action_text: text, user_email: user })
        .catch((e) => console.error('Failed to persist activity log entry', e));
    }
  };

  const isLight = settings.theme === 'light';
  const themeVars = isLight
    ? { bg: '#FFFFFF', surface: '#F4F6FA', elevated: '#E9EDF3', border: '#D7DEE8', text: '#1B2A57', muted: '#5B6B8C', scheme: 'light' }
    : { bg: '#000000', surface: '#0D0D0D', elevated: '#171717', border: '#282828', text: '#EDEDED', muted: '#8C8C8C', scheme: 'dark' };

  return (
    <div className="app-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');

        :root {
          --bg: ${themeVars.bg};
          --surface: ${themeVars.surface};
          --elevated: ${themeVars.elevated};
          --border: ${themeVars.border};
          --text: ${themeVars.text};
          --muted: ${themeVars.muted};
          --green: #2ECC8F;
          --green-soft: rgba(46,204,143,0.14);
          --yellow: #E8C547;
          --yellow-soft: rgba(232,197,71,0.14);
        }

        .app-root * { box-sizing: border-box; color-scheme: ${themeVars.scheme}; }
        .app-root {
          font-family: 'Inter', sans-serif;
          background: var(--bg);
          color: var(--text);
          display: flex;
          width: 100%;
          height: 100vh;
          min-height: 100vh;
          border-radius: 0;
          overflow: hidden;
          font-feature-settings: 'tnum' 1;
        }

        h1, h2, h3 { font-family: 'Space Grotesk', sans-serif; margin: 0; font-weight: 600; }

        /* Sidebar */
        .sidebar {
          width: 208px;
          flex-shrink: 0;
          background: var(--surface);
          border-right: 1px solid var(--border);
          display: flex;
          flex-direction: column;
          padding: 20px 14px;
        }
        .brand {
          display: flex;
          align-items: center;
          gap: 8px;
          color: var(--green);
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 13px;
          letter-spacing: 0.06em;
          padding: 0 8px 20px 8px;
        }
        nav { display: flex; flex-direction: column; gap: 2px; flex: 1; }
        .nav-item {
          display: flex;
          align-items: center;
          gap: 10px;
          background: transparent;
          border: none;
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 13.5px;
          padding: 9px 10px;
          border-radius: 6px;
          cursor: pointer;
          text-align: left;
        }
        .nav-item:hover { background: var(--elevated); color: var(--text); }
        .nav-item--active { background: var(--elevated); color: var(--text); }
        .nav-item--active svg { color: var(--green); }
        .nav-divider {
          height: 1px;
          background: var(--border);
          margin: 8px 6px;
        }

        .sidebar-footer {
          display: flex;
          align-items: center;
          gap: 9px;
          padding-top: 16px;
          border-top: 1px solid var(--border);
        }
        .dispatcher-badge {
          width: 30px; height: 30px;
          border-radius: 6px;
          background: var(--elevated);
          border: 1px solid var(--border);
          display: flex; align-items: center; justify-content: center;
          font-size: 11px; font-weight: 600; color: var(--green);
          flex-shrink: 0;
        }
        .dispatcher-name { font-size: 12.5px; font-weight: 500; }
        .dispatcher-role { font-size: 11px; color: var(--muted); }
        .sidebar-footer-info { flex: 1; min-width: 0; overflow: hidden; }
        .logout-btn {
          background: transparent;
          border: none;
          color: var(--muted);
          cursor: pointer;
          padding: 5px;
          border-radius: 5px;
          flex-shrink: 0;
          display: flex;
        }
        .logout-btn:hover { color: #FF6161; background: var(--elevated); }

        /* Page */
        .page { flex: 1; padding: 26px 30px; overflow-y: auto; }

        /* Main area + topbar */
        .main-area { flex: 1; display: flex; flex-direction: column; min-width: 0; }
        .topbar {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          padding: 14px 30px 0 30px;
          flex-shrink: 0;
        }

        /* Notification bell */
        .bell-wrap { position: relative; }
        .bell-btn {
          position: relative;
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--muted);
          border-radius: 6px;
          padding: 7px;
          cursor: pointer;
          display: flex;
        }
        .bell-btn:hover { color: var(--text); border-color: var(--green); }
        .bell-badge {
          position: absolute;
          top: -5px; right: -5px;
          background: var(--green);
          color: var(--bg);
          font-size: 9.5px;
          font-weight: 700;
          min-width: 15px;
          height: 15px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 3px;
        }
        .bell-panel {
          position: absolute;
          top: calc(100% + 8px);
          right: 0;
          width: 300px;
          max-height: 360px;
          overflow-y: auto;
          background: var(--elevated);
          border: 1px solid var(--border);
          border-radius: 8px;
          z-index: 70;
          padding: 8px;
        }
        .bell-panel-title { font-size: 12px; color: var(--muted); padding: 4px 8px 8px 8px; }
        .bell-empty { font-size: 12.5px; color: var(--muted); padding: 10px 8px; }
        .bell-entry { padding: 8px; border-radius: 6px; }
        .bell-entry:hover { background: var(--surface); }
        .bell-entry-text { font-size: 12.5px; color: var(--text); }
        .bell-entry-meta { font-size: 11px; color: var(--muted); margin-top: 2px; }

        /* Avatar (sidebar + settings) */
        .dispatcher-avatar { width: 30px; height: 30px; border-radius: 6px; object-fit: cover; flex-shrink: 0; }
        .avatar-upload-row { display: flex; align-items: center; gap: 10px; }
        .avatar-preview {
          width: 44px; height: 44px;
          border-radius: 8px;
          object-fit: cover;
          background: var(--elevated);
          border: 1px solid var(--border);
        }
        .avatar-preview--empty {
          display: flex; align-items: center; justify-content: center;
          font-size: 14px; font-weight: 600; color: var(--green);
        }
        .avatar-upload-btn { cursor: pointer; }

        /* Theme toggle */
        .theme-toggle-row { display: flex; gap: 8px; }
        .theme-option {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 12.5px;
          padding: 7px 16px;
          border-radius: 6px;
          cursor: pointer;
        }
        .theme-option--active { background: var(--green-soft); border-color: var(--green); color: var(--green); }

        /* Settings save */
        .settings-save-row { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
        .settings-saved-msg { font-size: 12px; color: var(--green); }
        .page-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          margin-bottom: 18px;
        }
        .page-header h1 { font-size: 21px; }
        .subtitle { color: var(--muted); font-size: 13px; margin-top: 4px; }

        /* Period selector (top-right) */
        .period-selector {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }
        .range-label { font-size: 12px; color: var(--muted); white-space: nowrap; }
        .custom-range { display: flex; align-items: center; gap: 6px; }
        .custom-range input {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 12px;
          padding: 6px 8px;
          border-radius: 6px;
        }
        .custom-range-sep { color: var(--muted); font-size: 11.5px; }
        .period-select {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 12.5px;
          padding: 7px 10px;
          border-radius: 6px;
          cursor: pointer;
        }
        .period-select:hover { border-color: var(--green); }
        .period-select:focus { outline: none; border-color: var(--green); }
        .driver-filter-row { display: flex; justify-content: flex-end; margin-bottom: 16px; }
        .dashboard-header-right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
        .dashboard-pdf-btn { display: flex; align-items: center; gap: 6px; }

        /* Stat list (no cards, no dividers between rows — plain minimal rows) */
        .stat-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: 22px;
        }
        .stat-row-item {
          display: flex;
          align-items: baseline;
          gap: 8px;
        }
        .stat-label { font-size: 13.5px; color: var(--text); }
        .stat-value { font-family: 'Space Grotesk', sans-serif; font-size: 15px; font-weight: 600; }
        .stat-divider {
          height: 1px;
          background: var(--border);
          margin: 4px 0 6px 0;
        }

        /* Panel */
        .panel {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 8px;
          padding: 16px 18px 18px 18px;
        }
        .panel-header {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          margin-bottom: 10px;
        }
        .panel-header h3 { font-size: 14.5px; }
        .panel-subtitle { font-size: 11.5px; color: var(--muted); }

        .chart-wrap { margin-top: 4px; }
        .empty-chart {
          height: 160px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--muted);
          font-size: 12.5px;
        }

        /* Placeholder */
        .placeholder { flex: 1; display: flex; align-items: center; justify-content: center; }
        .placeholder-inner { text-align: center; color: var(--muted); }
        .placeholder-inner h2 { color: var(--text); margin-bottom: 8px; }

        /* Buttons */
        .btn-primary {
          display: flex;
          align-items: center;
          gap: 6px;
          background: var(--green-soft);
          border: 1px solid var(--green);
          color: var(--green);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          font-weight: 500;
          padding: 8px 14px;
          border-radius: 6px;
          cursor: pointer;
        }
        .btn-primary:hover { background: rgba(46,204,143,0.22); }
        .btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
        .btn-ghost {
          background: transparent;
          border: 1px solid var(--border);
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          padding: 8px 14px;
          border-radius: 6px;
          cursor: pointer;
        }
        .btn-ghost:hover { color: var(--text); border-color: var(--text); }
        .icon-btn {
          background: transparent;
          border: none;
          color: var(--muted);
          cursor: pointer;
          padding: 5px;
          border-radius: 5px;
          display: flex;
          align-items: center;
        }
        .icon-btn:hover { background: var(--elevated); color: var(--text); }

        /* Empty state */
        .empty-state {
          color: var(--muted);
          font-size: 13px;
          padding: 20px 0;
        }

        /* Drivers plain list */
        .driver-plain-list { display: flex; flex-direction: column; gap: 2px; }
        .driver-plain-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px 4px;
          border-bottom: 1px solid var(--border);
        }
        .driver-plain-row:last-child { border-bottom: none; }
        .driver-plain-info { display: flex; align-items: baseline; gap: 10px; }
        .driver-plain-name { font-size: 13.5px; }
        .driver-plain-type { font-size: 12px; color: var(--muted); }
        .driver-plain-actions { display: flex; gap: 2px; }

        .confirm-row {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12.5px;
          color: var(--muted);
        }
        .btn-ghost-sm, .btn-danger-sm {
          font-family: 'Inter', sans-serif;
          font-size: 12px;
          padding: 4px 10px;
          border-radius: 5px;
          cursor: pointer;
        }
        .btn-ghost-sm {
          background: transparent;
          border: 1px solid var(--border);
          color: var(--muted);
        }
        .btn-ghost-sm:hover { color: var(--text); }
        .btn-danger-sm {
          background: rgba(255,97,97,0.12);
          border: 1px solid #FF6161;
          color: #FF6161;
        }
        .btn-danger-sm:hover { background: rgba(255,97,97,0.22); }

        /* Modal */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(5,9,18,0.6);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 50;
        }
        .modal {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 10px;
          width: 360px;
          max-width: 90%;
          padding: 18px 20px 20px 20px;
        }
        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 14px;
        }
        .modal-header h3 { font-size: 15px; }
        .modal-body { display: flex; flex-direction: column; gap: 12px; }
        .field-row { display: flex; flex-direction: column; gap: 5px; }
        .field-row label { font-size: 12px; color: var(--muted); }
        .field-row input, .field-row select {
          background: var(--elevated);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          padding: 8px 10px;
          border-radius: 6px;
        }
        .field-row input:focus, .field-row select:focus {
          outline: none;
          border-color: var(--green);
        }
        .modal-footer {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
          margin-top: 16px;
        }

        /* Settings page (reuses .field-row styling from modal) */
        .settings-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
          max-width: 320px;
        }

        /* Loads toolbar */
        .loads-toolbar {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 16px;
        }
        .search-box {
          display: flex;
          align-items: center;
          gap: 7px;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 6px;
          padding: 7px 10px;
          flex: 1;
          max-width: 260px;
        }
        .search-icon { color: var(--muted); flex-shrink: 0; }
        .search-box input {
          background: transparent;
          border: none;
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 12.5px;
          width: 100%;
        }
        .search-box input:focus { outline: none; }

        /* Loads table */
        .loads-table { display: flex; flex-direction: column; }
        .loads-row {
          display: grid;
          grid-template-columns: 20px 26px 110px 90px 150px 150px 110px 100px 100px 90px 60px;
          align-items: center;
          gap: 10px;
          padding: 10px 4px;
          border-bottom: 1px solid var(--border);
          font-size: 12.5px;
        }
        .loads-row--head {
          color: var(--muted);
          font-size: 11.5px;
          border-bottom: 1px solid var(--border);
          padding-bottom: 8px;
        }
        .loads-row--overdue { background: rgba(255,97,97,0.06); border-left: 2px solid #FF6161; padding-left: 2px; }
        .loads-sort-btn {
          background: none;
          border: none;
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 11.5px;
          cursor: pointer;
          padding: 0;
          text-align: left;
          display: flex;
          align-items: center;
          gap: 3px;
        }
        .loads-sort-btn:hover { color: var(--text); }
        .sort-arrow { color: var(--green); font-size: 10px; }
        .loads-header-actions { display: flex; gap: 8px; align-items: center; }
        .overdue-banner {
          display: flex;
          align-items: center;
          gap: 8px;
          background: rgba(255,97,97,0.1);
          border: 1px solid #FF6161;
          color: #FF6161;
          border-radius: 6px;
          padding: 10px 14px;
          font-size: 12.5px;
          margin-bottom: 14px;
        }
        .bulk-bar {
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--elevated);
          border: 1px solid var(--green);
          border-radius: 6px;
          padding: 8px 12px;
          font-size: 12.5px;
          margin-bottom: 12px;
        }
        .pagination-row {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding-top: 14px;
        }
        .pagination-label { font-size: 12px; color: var(--muted); }
        .loads-row:last-child { border-bottom: none; }
        .loads-n { color: var(--muted); }
        .loads-number-cell { display: flex; flex-direction: column; gap: 2px; }
        .parent-hint {
          display: flex;
          align-items: center;
          gap: 3px;
          font-size: 10.5px;
          color: var(--muted);
        }
        .loads-ellipsis {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* Field helper text */
        .field-error { font-size: 11px; color: #FF6161; }
        .field-hint { font-size: 11px; color: var(--muted); }
        .truck-readonly {
          background: var(--elevated);
          border: 1px solid var(--border);
          color: var(--muted);
          font-size: 13px;
          padding: 8px 10px;
          border-radius: 6px;
        }

        /* Combobox (search-or-pick) */
        .combobox { position: relative; }
        .combobox input {
          width: 100%;
          background: var(--elevated);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          padding: 8px 10px;
          border-radius: 6px;
        }
        .combobox input:focus { outline: none; border-color: var(--green); }
        .combobox-list {
          position: absolute;
          top: calc(100% + 4px);
          left: 0;
          right: 0;
          background: var(--elevated);
          border: 1px solid var(--border);
          border-radius: 6px;
          max-height: 180px;
          overflow-y: auto;
          z-index: 60;
        }
        .combobox-option {
          padding: 8px 10px;
          font-size: 12.5px;
          cursor: pointer;
        }
        .combobox-option:hover { background: var(--surface); color: var(--green); }
        .combobox-option--action {
          border-top: 1px solid var(--border);
          color: var(--green);
          font-weight: 500;
        }
        .combobox-empty {
          padding: 8px 10px;
          font-size: 12px;
          color: var(--muted);
        }

        /* Inline "add a new city" mini-form (replaces the combobox while active) */
        .city-add-form {
          display: flex;
          flex-direction: column;
          gap: 6px;
          background: var(--elevated);
          border: 1px solid var(--green);
          border-radius: 6px;
          padding: 8px;
        }
        .city-add-form input, .city-add-form select {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 12.5px;
          padding: 7px 9px;
          border-radius: 6px;
        }
        .city-add-actions {
          display: flex;
          justify-content: flex-end;
          gap: 6px;
        }
        .btn-primary-sm {
          background: var(--green-soft);
          border: 1px solid var(--green);
          color: var(--green);
          font-family: 'Inter', sans-serif;
          font-size: 12px;
          padding: 4px 10px;
          border-radius: 5px;
          cursor: pointer;
        }
        .btn-primary-sm:hover { background: rgba(46,204,143,0.22); }

        /* Inline status select in the loads table */
        .status-inline-select {
          background: var(--surface);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 12px;
          padding: 4px 6px;
          border-radius: 5px;
          cursor: pointer;
        }
        .status-inline-select:focus { outline: none; border-color: var(--green); }
        .status-inline-select--pickedup {
          background: var(--yellow-soft);
          border-color: var(--yellow);
          color: var(--yellow);
        }
        .status-inline-select--delivered {
          background: var(--green-soft);
          border-color: var(--green);
          color: var(--green);
        }

        /* Toggle switch */
        .toggle-row {
          display: flex;
          align-items: center;
          gap: 8px;
          background: none;
          border: none;
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          cursor: pointer;
          padding: 2px 0;
        }
        .toggle-track {
          width: 32px;
          height: 18px;
          border-radius: 10px;
          background: var(--border);
          position: relative;
          display: inline-block;
          transition: background 0.15s;
        }
        .toggle-track--on { background: var(--green); }
        .toggle-thumb {
          position: absolute;
          top: 2px; left: 2px;
          width: 14px; height: 14px;
          border-radius: 50%;
          background: var(--text);
          transition: transform 0.15s;
        }
        .toggle-track--on .toggle-thumb { transform: translateX(14px); }

        /* Wide modal for Loads */
        .modal--wide { width: 420px; }

        .confirm-row--table {
          display: flex;
          gap: 6px;
        }

        /* Week navigator (Salary) */
        .week-nav {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-shrink: 0;
        }
        .week-nav-label {
          font-size: 12.5px;
          color: var(--muted);
          white-space: nowrap;
          min-width: 150px;
          text-align: center;
        }
        .salary-export-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-left: 6px;
        }

        /* Salary table (spreadsheet-style, merged colored blocks for active days) */
        .salary-table-wrap {
          overflow-x: auto;
          border: 1px solid var(--border);
          border-radius: 8px;
        }
        .salary-table { display: flex; flex-direction: column; min-width: 820px; }
        .salary-row {
          display: grid;
          grid-template-columns: 90px 170px 100px repeat(7, minmax(84px, 1fr));
          align-items: stretch;
          gap: 0;
        }
        .salary-row > span, .salary-row > button {
          padding: 10px 12px;
          display: flex;
          align-items: center;
        }
        .salary-row--head {
          background: var(--elevated);
          color: var(--muted);
          font-size: 11.5px;
          font-weight: 500;
          border-bottom: 1px solid var(--border);
        }
        .salary-row--head > span:nth-child(3) { border-right: 1px solid var(--border); }
        .salary-head-sub { color: var(--muted); font-size: 10px; margin-left: 4px; }
        .salary-row:not(.salary-row--head) { border-bottom: 1px solid var(--border); }
        .salary-row:last-child { border-bottom: none; }
        .salary-truck { font-size: 12.5px; color: var(--muted); background: var(--surface); }
        .salary-driver-name { font-size: 13px; background: var(--surface); }
        .salary-total {
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 13px;
          background: var(--surface);
          border-right: 1px solid var(--border);
        }
        .salary-cell {
          background: transparent;
          border: none;
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 12.5px;
          cursor: pointer;
          text-align: left;
        }
        .salary-cell:hover { filter: brightness(1.15); }
        .salary-cell--active {
          background: var(--green-soft);
          color: var(--green);
          font-weight: 600;
        }
        .salary-cell--multi {
          background: var(--yellow-soft);
          color: var(--yellow);
          font-weight: 600;
        }
        .salary-cell-empty { color: var(--muted); font-size: 11px; font-weight: 400; }

        /* Day detail modal (Salary) */
        .salary-detail-list { display: flex; flex-direction: column; gap: 10px; }
        .salary-detail-row {
          display: flex;
          flex-direction: column;
          gap: 3px;
          padding-bottom: 10px;
          border-bottom: 1px solid var(--border);
        }
        .salary-detail-main { display: flex; gap: 10px; align-items: baseline; }
        .salary-detail-load { font-weight: 600; font-size: 13px; }
        .salary-detail-route { font-size: 12px; color: var(--muted); }
        .salary-detail-nums { display: flex; gap: 14px; font-size: 12px; color: var(--muted); }
        .salary-detail-net { color: var(--green); font-weight: 500; }
        .salary-detail-total {
          display: flex;
          justify-content: space-between;
          padding-top: 4px;
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 14px;
        }

        /* Calendar */
        .cal-grid {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 6px;
        }
        .cal-weekday {
          text-align: left;
          font-size: 11.5px;
          color: var(--muted);
          padding: 0 4px 6px 4px;
        }
        .cal-cell {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 6px;
          min-height: 84px;
          padding: 8px;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: 6px;
          cursor: pointer;
          text-align: left;
        }
        .cal-cell:hover { border-color: var(--green); }
        .cal-cell--empty { background: transparent; border: none; cursor: default; }
        .cal-cell--today { border-color: var(--green); }
        .cal-daynum { font-family: 'Space Grotesk', sans-serif; font-size: 13px; font-weight: 600; color: var(--text); }
        .cal-cell--today .cal-daynum { color: var(--green); }
        .cal-note-preview {
          display: flex;
          align-items: center;
          gap: 5px;
          font-size: 11px;
          color: var(--muted);
          line-height: 1.3;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          width: 100%;
        }
        .cal-note-dot {
          width: 6px; height: 6px; border-radius: 50%;
          background: var(--green);
          flex-shrink: 0;
        }

        /* Notes modal */
        .notes-list { display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; }
        .notes-row {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 8px;
          padding: 8px 10px;
          background: var(--elevated);
          border-radius: 6px;
          font-size: 13px;
        }
        .notes-add-row { display: flex; gap: 8px; }
        .notes-add-row input {
          flex: 1;
          background: var(--elevated);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          padding: 8px 10px;
          border-radius: 6px;
        }
        .notes-add-row input:focus { outline: none; border-color: var(--green); }

        /* Logout screen */
        .logout-screen {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .logout-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          text-align: center;
          color: var(--green);
          max-width: 280px;
        }
        .logout-card h2 { font-size: 17px; color: var(--text); margin-top: 6px; }
        .logout-card p { font-size: 12.5px; color: var(--muted); margin: 0 0 8px 0; }

        /* Auth screen */
        .auth-screen {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
        }
        .auth-card {
          display: flex;
          flex-direction: column;
          gap: 12px;
          width: 300px;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 10px;
          padding: 26px 24px;
        }
        .auth-brand {
          display: flex;
          align-items: center;
          gap: 8px;
          color: var(--green);
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 13px;
          letter-spacing: 0.06em;
          margin-bottom: 4px;
        }
        .auth-card h2 { font-size: 17px; margin-bottom: 4px; }
        .auth-submit { justify-content: center; margin-top: 4px; }
        .auth-switch {
          background: none;
          border: none;
          color: var(--muted);
          font-family: 'Inter', sans-serif;
          font-size: 12px;
          cursor: pointer;
          text-align: center;
          padding: 4px 0 0 0;
        }
        .auth-switch:hover { color: var(--green); }
      `}</style>

      {!sessionChecked ? (
        <div className="logout-screen"><span className="pagination-label">Loading…</span></div>
      ) : !session ? (
        <AuthScreen onAuthenticated={handleAuthenticated} />
      ) : (
        <>
          <Sidebar active={active} onSelect={setActive} dispatcherName={settings.dispatcherName} avatarUrl={settings.avatarUrl} onLogout={handleLogout} />
          <div className="main-area">
            <div className="topbar">
              <NotificationBell log={activityLog} />
            </div>
            {active === 'dashboard' && <Dashboard loads={loads} drivers={drivers} settings={settings} />}
            {active === 'loads' && <Loads loads={loads} setLoads={setLoads} drivers={drivers} customCities={customCities} setCustomCities={setCustomCities} logActivity={logActivity} accessToken={session.accessToken} />}
            {active === 'drivers' && <Drivers drivers={drivers} setDrivers={setDrivers} logActivity={logActivity} accessToken={session.accessToken} />}
            {active === 'salary' && <Salary loads={loads} drivers={drivers} />}
            {active === 'calendar' && <Calendar calendarNotes={calendarNotes} setCalendarNotes={setCalendarNotes} logActivity={logActivity} accessToken={session.accessToken} userId={session.userId} />}
            {active === 'settings' && <SettingsPage settings={settings} setSettings={setSettings} onSave={() => logActivity('Updated settings')} accessToken={session.accessToken} />}
            {active !== 'dashboard' && active !== 'loads' && active !== 'drivers' && active !== 'salary' && active !== 'calendar' && active !== 'settings' && (
              <Placeholder label={navItems.find(n => n.id === active).label} />
            )}
          </div>
        </>
      )}
    </div>
  );
}
